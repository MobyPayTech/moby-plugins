# Moby Checkout Opencart 3

# App uses :
-   PHP

# Tech :
- backend PHP

# Install :
```shell
git clone git@github.com:MobyPayTech/moby-checkout-opencart3.git
cd moby-checkout-opencart3/
zip -r mobypay.ocmod.zip ./*
```


