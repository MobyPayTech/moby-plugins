<?php

class ModelExtensionPaymentMobypay extends Model {


}

