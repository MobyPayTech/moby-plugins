<?php


$_['heading_title'] 		= 'Moby Checkout';
$_['error_order_id']		= 'No order ID in the session!';
$_['error_payment_method']	= 'Payment method not supported';
$_['error_currency']		= 'Currency not supported.';
$_['text_title']			= 'Moby Checkout';
