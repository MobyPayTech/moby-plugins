<?php

class ModelExtensionPaymentMobypay extends Controller {

    public function getCurrency() {
        return ['MYR'];
    }

    public function getMethod($address, $total) {
        $this->load->language('extension/payment/mobypay');
        
        $methodData = [
            'code'       => 'mobypay',
            'title'      => $this->language->get('text_title'),
            'terms'      => '',
            'sort_order' => $this->config->get('payment_mobypay_sort_order')
        ];

        return $methodData;

    }


}
