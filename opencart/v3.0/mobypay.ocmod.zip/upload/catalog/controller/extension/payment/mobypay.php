<?php

class ControllerExtensionPaymentMobypay extends Controller {

    const MOBYPAY_API_DEVELOPMENT = 'https://dev.pay.mobycheckout.com';
    const MOBYPAY_API_PRODUCTION  = 'https://pay.mobycheckout.com';

    /**
     * @return mixed
     */
    public function index() {
        $extensionMobypay = 'extension/payment/mobypay';

        $this->load->language( $extensionMobypay );

        $data['language']                    = $this->config->get( 'config_language' );
        $data['payment_mobypay_title']       = $this->config->get( 'payment_mobypay_title' );
        $data['payment_mobypay_description'] = $this->config->get( 'payment_mobypay_description' );
        $data['default_template']            = $this->config->get( 'config_template' ) == 'default' || $this->config->get( 'config_template' ) == '';

        return $this->load->view( $extensionMobypay, $data );
    }

    public function confirm() {
        $this->load->language( 'extension/payment/mobypay' );
        $json = [];

        $currency = explode( ', ', $this->config->get( 'payment_mobypay_currency' ) );

        if ( !isset( $this->session->data['order_id'] ) ) {
            $json['error'] = $this->language->get( 'error_order_id' );
        } elseif ( !isset( $this->session->data['payment_method'] ) || $this->session->data['payment_method']['code'] !== 'mobypay' ) {
            $json['error'] = $this->language->get( 'error_payment_method' );
        } elseif ( !in_array( $this->session->data['currency'], $currency ) ) {
            $json['error'] = $this->language->get( 'error_currency' );
        }

        if ( !$json ) {
            $this->load->model( 'checkout/order' );
            $orderInfo          = $this->model_checkout_order->getOrder( $this->session->data['order_id'] );
            $orderInfo['items'] = $this->cart->getProducts();
            $order_id           = $this->session->data['order_id'];

            $cart['cart']['amount'] = number_format( $orderInfo['total'], 2 );
            $cart['cart']['items']  = [];

            foreach ( $orderInfo['items'] as $item ) {
                $cart['cart']['items'][] = [
                    'product'  => [
                        'id'    => (int) $item['product_id'],
                        'title' => $item['name'],
                        'price' => number_format( $item['price'], 2 ),
                    ],
                    'amount'   => number_format( $item['total'], 2 ),
                    'quantity' => $item['quantity'],
                ];
            }

            $amount          = $this->currency->format( $orderInfo['total'], $orderInfo['currency_code'], $orderInfo['currency_value'], false );
            $finalAmount     = str_replace( ',', '', number_format( $amount, 2, '.', '' ) );
            $mobypayApi      = html_entity_decode( $this->config->get( 'payment_mobypay_api' ), ENT_QUOTES, 'UTF-8' );
            $mobypayClientID = html_entity_decode( $this->config->get( 'payment_mobypay_client_id' ), ENT_QUOTES, 'UTF-8' );
            $mobypayCustName = trim( $orderInfo['firstname'] . ' ' . ( isset( $orderInfo['lastname'] ) ? $orderInfo['lastname'] : '' ) );
            $mobypayEmail    = $orderInfo['email'];
            $mobypayMobile   = ( $orderInfo['telephone'] !== '' ) ? $orderInfo['telephone'] : '+60100000000';
            $returnUrl       = $this->url->link( 'extension/payment/mobypay/response' ) . '&mobypay_order_id=' . $order_id . '&';
            $callbackUrl     = $this->url->link( 'extension/payment/mobypay/callback' ) . '&mobypay_order_id=' . $order_id . '&';
            $store_name      = $this->config->get( 'config_name' );

            $referenceNo = sprintf( "%06s", $this->session->data['order_id'] );

            $data = [
                "clientId"       => $mobypayClientID,
                "referenceNo"    => (string) $this->session->data['order_id'],
                "details"        => $store_name . ' Order #' . $referenceNo,
                "amount"         => $finalAmount,
                "customerName"   => $mobypayCustName,
                "customerEmail"  => $mobypayEmail,
                "customerMobile" => $mobypayMobile,
                "returnUrl"      => $returnUrl,
                "callbackUrl"    => $callbackUrl,
                "additionalInfo" => $cart,
            ];

            $token = $this->getToken( $mobypayApi, $mobypayClientID );

            if ( empty( $token->token ) ) {
                $message = $token->msg ?? $token->error ?? null;
                $json['error'] = $message ?: 'Something went wrong.';
            } else {
                $token  = $token->token;
                $header = [
                    'Authorization: Bearer ' . $token,
                    'Content-Type: application/json',
                ];
                $url      = $this->getUrl() . '/api/merchant/payment/checkout/hosted';
                $response = json_decode( $this->post( $url, json_encode( $data ), $header ) );

                if ( isset( $response->error ) ) {
                    $json['error'] = isset( $response->msg ) ? $response->msg : $response->error;
                } elseif ( !isset( $response->payLink ) ) {
                    $json['error'] = 'Something went wrong.';
                } else {
                    $json['redirect'] = $response->payLink;
                }
            }
        }

        $this->response->addHeader( 'Content-Type: application/json' );
        $this->response->setOutput( json_encode( $json ) );
    }

    /**
     * @param $data
     */
    public function apiResponse( $data ): void {
        header( 'Content-Type: application/json; charset=utf-8' );
        echo json_encode( $data );
        exit;
    }

    public function callback() {
        $this->load->model( 'checkout/order' );
        if ( !$this->validate_hmac() ) {
            $this->apiResponse( ['status' => 'failed', 'error' => 'Invalid HMAC'] );
        } else {
            $params         = $this->request();
            $order_id       = (int) ( $params['mobypay_order_id'] ?? 0 );
            $status         = $params['status'] ?? 'failed';
            $transaction_id = $params['transactionId'] ?? null;
            $payMethod      = $params['payMethod'] ?? null;
            $time           = $params['time'] ?? null;
            $message        = $transaction_id ? "Transaction ID: {$transaction_id}\n" : '';
            $message .= $payMethod ? "Payment Method: {$payMethod}\n" : '';
            $message .= $time ? "Time: {$time}\n" : '';

            if ( !$status ) {
                $this->apiResponse( ['error' => 'Status is missing.', 'status' => 'failed'] );
            }

            if ( !$order_id ) {
                $this->apiResponse( ['error' => 'Mobypay order id is missing.', 'status' => 'failed'] );
            }

            if ( !$transaction_id ) {
                $this->apiResponse( ['error' => 'Transaction id is missing.', 'status' => 'failed'] );
            }

            $this->load->model( 'checkout/order' );
            $orderInfo = $this->model_checkout_order->getOrder( $order_id );

            if ( !$orderInfo ) {
                $this->apiResponse( ['error' => 'Order not found', 'status' => 'failed'] );
            }

            $status_success = $this->config->get( 'payment_mobypay_paid_status_id' );
            $status_reject  = $this->config->get( 'payment_mobypay_rejected_status_id' );
            $status_refund  = $this->config->get( 'payment_mobypay_refunded_status_id' );

            switch ( $status ) {
                case "success":
                    if ( $orderInfo['order_status_id'] != $status_success ) {
                        $this->model_checkout_order->addOrderHistory( $order_id, $status_success, $message, true );
                    }
                    $this->apiResponse( ['message' => 'Callback received successfully', 'status' => 'success'] );
                    break;
                case "failed":
                    if (
                        $orderInfo['order_status_id'] != $status_success &&
                        $orderInfo['order_status_id'] != $status_reject
                    ) {
                        $this->model_checkout_order->addOrderHistory( $order_id, $status_reject );
                    }
                    $this->apiResponse( ['message' => 'Callback received successfully', 'status' => 'success'] );
                    break;
                case "refunded":
                    if ( $orderInfo['order_status_id'] == $status_success ) {
                        $this->model_checkout_order->addOrderHistory( $order_id, $status_refund, $message, true );
                    }
                    $this->apiResponse( ['message' => 'Callback received successfully', 'status' => 'success'] );
                    break;
                default:
                    $this->apiResponse( ['message' => 'Callback received successfully', 'status' => 'success'] );
                    break;
            }
        }
    }

    public function request() {
        // Capture raw request body
        $request_body = file_get_contents( 'php://input' );

        // Parse JSON data if the content type is application/json
        $json_data = [];
        if ( isset( $_SERVER['CONTENT_TYPE'] ) && strpos( $_SERVER['CONTENT_TYPE'], 'application/json' ) !== false ) {
            $json_data = json_decode( $request_body, true ) ?? [];
        }

        // Merge all possible input sources
        return array_merge( $_GET, $_POST, $json_data );
    }

    public function response() {
        $this->load->model( 'checkout/order' );
        if ( !$this->validate_hmac() ) {
            $this->response->redirect( '/' );
        } else {
            $params         = $this->request();
            $order_id       = (int) ( $params['mobypay_order_id'] ?? 0 );
            $status         = $params['status'] ?? 'failed';
            $transaction_id = $params['transactionId'] ?? null;
            $payMethod      = $params['payMethod'] ?? null;
            $time           = $params['time'] ?? null;
            $message        = $transaction_id ? "Transaction ID: {$transaction_id}\n" : '';
            $message .= $payMethod ? "Payment Method: {$payMethod}\n" : '';
            $message .= $time ? "Time: {$time}\n" : '';

            $this->load->model( 'checkout/order' );
            $orderInfo = $this->model_checkout_order->getOrder( $order_id );

            if ( $orderInfo ) {
                $status_success = $this->config->get( 'payment_mobypay_paid_status_id' );
                $status_reject  = $this->config->get( 'payment_mobypay_rejected_status_id' );
                $status_refund  = $this->config->get( 'payment_mobypay_refunded_status_id' );

                if ( $status == "success" ) {
                    if ( $orderInfo['order_status_id'] != $status_success ) {
                        $this->model_checkout_order->addOrderHistory( $order_id, $status_success, $message, true );
                    }
                    $this->response->redirect( $this->url->link( 'checkout/success', '', true ) );
                } elseif ( $status == "failed" ) {
                    if ( $orderInfo['order_status_id'] != $status_success && $orderInfo['order_status_id'] != $status_reject ) {
                        $this->model_checkout_order->addOrderHistory( $order_id, $status_reject );
                    }
                    $this->response->redirect( $this->url->link( 'checkout/failure', '', true ) );
                } elseif ( $status == "refunded" ) {
                    if ( $orderInfo['order_status_id'] == $status_success ) {
                        $this->model_checkout_order->addOrderHistory( $order_id, $status_refund, $message, true );
                    }
                    $this->response->redirect( $this->url->link( 'checkout/success', '', true ) );
                } else {
                    $this->response->redirect( '/' );
                }
            } else {
                $this->response->redirect( '/' );
            }
        }
    }

    /**
     * @param $mobypayApi
     * @param $mobypayClientID
     */
    public function getToken( $mobypayApi, $mobypayClientID ) {
        $payload['clientId']  = $mobypayClientID;
        $payload['secretKey'] = $mobypayApi;

        $url = $this->getUrl() . '/api/auth/token';
        return json_decode( $this->post( $url, json_encode( $payload ) ) );
    }

    /**
     * @return mixed
     */
    public function getUrl() {
        if ( $this->config->get( 'payment_mobypay_test_mode' ) ) {
            $url = self::MOBYPAY_API_DEVELOPMENT;
        } else {
            $url = self::MOBYPAY_API_PRODUCTION;
        }

        return $url;
    }

    public function validate_hmac() {
        $params      = $this->request();
        $signature   = $params['signature'] ?? '';
        $referenceNo = $params['referenceNo'] ?? '';

        unset( $params['signature'] );
        unset( $params['route'] );
        unset( $params['mobypay_order_id'] );
        unset( $params['referenceNo'] );

        $params['referenceNo'] = $referenceNo;
        ksort( $params );
        $params  = implode( '', $params );
        $api_key = $this->config->get( 'payment_mobypay_api' );

        $generated_signature = hash_hmac( 'sha256', $params, $api_key );

        return hash_equals( $signature, $generated_signature );
    }

    /**
     * @param $data
     * @param $code
     */
    public function json( $data, $code = 200 ) {
        for ( $i = 0; $i < ob_get_status()['level']; $i++ ) {
            ob_end_clean();
        }

        http_response_code( $code );
        header( 'Content-Type: application/json' );
        echo json_encode( $data );
        die;
    }

    /**
     * @param  $url
     * @param  $data
     * @param  $header
     * @return mixed
     */
    public function post( $url, $data, $header = null ) {
        $curl    = curl_init();
        $options = [
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_URL            => $url,
            CURLOPT_USERAGENT      => 'Mobypay',
            CURLOPT_CUSTOMREQUEST  => "POST",
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $data,
        ];

        if ( !$header ) {
            $header = [];
        }

        $header[]                    = "Content-Type: application/json";
        $options[CURLOPT_HTTPHEADER] = $header;

        curl_setopt_array( $curl, $options );
        $resp = curl_exec( $curl );
        curl_close( $curl );

        return $resp;
    }
}
