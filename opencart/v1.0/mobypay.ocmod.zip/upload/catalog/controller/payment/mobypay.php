<?php

class ControllerPaymentMobypay extends Controller {

    const MOBYPAY_API_DEVELOPMENT = 'https://dev.pay.mobycheckout.com';
    const MOBYPAY_API_PRODUCTION = 'https://pay.mobycheckout.com';

    public function index() {
        $extensionMobypay = 'payment/mobypay';

        $this->load->language($extensionMobypay);

        $this->template = 'default/template/payment/mobypay.tpl';
        $data['language']           = $this->config->get('config_language');
        $data['mobypay_title'] = $this->config->get('mobypay_title');
        $data['mobypay_description'] = $this->config->get('mobypay_description');
        $data['default_template'] = $this->config->get('config_template') == 'default';

        $this->data = $data;
        $this->response->setOutput($this->render());
    }

    public function confirm() {
        $this->load->language('payment/mobypay');
        $json = array();

        $currency = explode(', ', $this->config->get('mobypay_currency'));

        if (!isset($this->session->data['order_id'])) {
            $json['error'] = $this->language->get('error_order_id');
        } elseif (!isset($this->session->data['payment_method']) || $this->session->data['payment_method']['code'] !== 'mobypay') {
            $json['error'] = $this->language->get('error_payment_method');
        } elseif (!in_array($this->session->data['currency'], $currency)) {
            $json['error'] = $this->language->get('error_currency');
        }

        if (!$json) {
            $this->load->model('checkout/order');
            $orderInfo = $this->model_checkout_order->getOrder($this->session->data['order_id']);
            $orderInfo['items'] = $this->cart->getProducts();
            $order_id = $this->session->data['order_id'];

            $cart['cart']['amount'] = number_format($orderInfo['total'], 2);
            $cart['cart']['items'] = [];

            foreach($orderInfo['items'] as $item) {
                $cart['cart']['items'][] = [
                    'product' => [
                        'id' => (int) $item['product_id'],
                        'title' => $item['name'],
                        'price' => number_format($item['price'], 2),
                    ],
                    'amount' => number_format($item['total'], 2),
                    'quantity' => $item['quantity'],
                ];
            }

            $amount          = $this->currency->format($orderInfo['total'], $orderInfo['currency_code'], $orderInfo['currency_value'], false);
            $finalAmount     = str_replace(',', '', number_format($amount, 2, '.', ''));
            $mobypayApi      = html_entity_decode($this->config->get('mobypay_api'), ENT_QUOTES, 'UTF-8');
            $mobypayClientID = html_entity_decode($this->config->get('mobypay_client_id'), ENT_QUOTES, 'UTF-8');
            $mobypayCustName = trim($orderInfo['firstname'].' '.(isset($orderInfo['lastname']) ? $orderInfo['lastname'] : ''));
            $mobypayEmail    = $orderInfo['email'];
            $mobypayMobile   = ($orderInfo['telephone'] !== '') ? $orderInfo['telephone'] : '+60100000000';
            $returnUrl       = $this->url->link('payment/mobypay/response').'&mobypay_order_id='.$order_id.'&';
            $store_name      = $this->config->get('config_name');

            $referenceNo = sprintf("%06s", $this->session->data['order_id']);
      
            $data = array(
                "clientId"          => $mobypayClientID,
                "referenceNo"       => (string) $this->session->data['order_id'],
                "details"           => $store_name.' Order #'.$referenceNo,
                "amount"            => $finalAmount,
                "customerName"      => $mobypayCustName,
                "customerEmail"     => $mobypayEmail,
                "customerMobile"    => $mobypayMobile,
                "returnUrl"         => $returnUrl,
                "additionalInfo"    => $cart,
            );

            $token = $this->getToken($mobypayApi, $mobypayClientID);

            if (empty($token->token)) {
                $json['error'] = isset($token->error) ? (isset($token->msg) ? $token->msg : $token->error) : 'Oopss. Something is wrong with merchant\'s Mobypay\'s account.';
            } else {
                $token = $token->token;
                $header = array(
                    'Authorization: Bearer '.$token,
                );
                $url = $this->getUrl().'/api/merchant/payment/checkout/hosted';
                $response = json_decode($this->post($url, json_encode($data), $header));

                if (isset($response->error)) {
                    $json['error'] = isset($response->msg) ? $response->msg : $response->error;
                } elseif (!isset($response->payLink)) {
                    $json['error'] = 'Oopss. Something went wrong. Paylink is not returned';
                } else {
                    $json['redirect'] = $response->payLink;
                    $this->model_checkout_order->confirm($order_id, '1');
                }
            }
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function response() {
        $this->load->model('checkout/order');

        if (!$this->validate_hmac()) {
            $this->response->redirect('/');
        } else {
            $params = $_GET;
            $order_id = (int) (isset($params['mobypay_order_id']) ? $params['mobypay_order_id'] : 0);
            $status = isset($params['?status']) ? $params['?status'] : (isset($params['status']) ? $params['status'] : 'failed');
            $transaction_id = isset($params['transactionId']) ? $params['transactionId'] : (isset($params['?transactionId']) ? $params['?transactionId'] : null);
            $payMethod = isset($params['payMethod']) ? $params['payMethod'] : (isset($params['?payMethod']) ? $params['?payMethod'] : null);
            $time = isset($params['time']) ? $params['time'] : (isset($params['?time']) ? $params['?time'] : null);
            $message = ($transaction_id) ? 'Transaction ID: '.$transaction_id."\n" : '';
            $message .= ($payMethod) ? 'Payment Method: '.$payMethod."\n" : '';
            $message .= ($time) ? 'Time: '.$time."\n" : '';

            $this->load->model('checkout/order');
            $orderInfo = $this->model_checkout_order->getOrder($order_id);

            if ($orderInfo) {
                $status_success = $this->config->get('mobypay_paid_status_id');
                $status_reject = $this->config->get('mobypay_rejected_status_id');
                $status_refund = $this->config->get('mobypay_refunded_status_id');

                if ($status == "success") {
                    if ($orderInfo['order_status_id'] != $status_success) {
                        $this->model_checkout_order->update($order_id, $status_success, $message, true);
                    }
                    $this->response->redirect($this->url->link('checkout/success', '', true));
                } elseif ($status == "failed") {
                    if ($orderInfo['order_status_id'] != $status_success && $orderInfo['order_status_id'] != $status_reject) {
                        $this->model_checkout_order->update($order_id, $status_reject);
                    }
                    $this->response->redirect($this->url->link('checkout/cart', '', true));
                } elseif ($status == "refunded") {
                    if ($orderInfo['order_status_id'] == $status_success) {
                        $this->model_checkout_order->update($order_id, $status_refund, $message, true);
                    }
                    $this->response->redirect($this->url->link('checkout/success', '', true));
                } else {
                    $this->response->redirect('/');
                }
            } else {
                $this->response->redirect('/');
            }
        }
    }

    public function getToken($mobypayApi, $mobypayClientID) {
        $payload['clientId'] = $mobypayClientID;
        $payload['secretKey'] = $mobypayApi;

        $url = $this->getUrl().'/api/auth/token';
        return json_decode($this->post($url, json_encode($payload)));
    }

    public function getUrl() {
        if ($this->config->get('mobypay_test_mode')) {
            $url = self::MOBYPAY_API_DEVELOPMENT;
        } else {
            $url = self::MOBYPAY_API_PRODUCTION;
        }

        return $url;
    }

    public function validate_hmac() {
        $params = $_GET;
        $signature = isset($params['signature']) ? $params['signature'] : '';
        $referenceNo = isset($params['?referenceNo']) ? $params['?referenceNo'] : (isset($params['referenceNo']) ? $params['referenceNo'] : '');
        
        unset($params['signature']);
        unset($params['route']);
        unset($params['mobypay_order_id']);
        unset($params['?referenceNo']);

        $params['referenceNo'] = $referenceNo;
        ksort($params);
        $params = implode('', $params);
        $api_key = $this->config->get('mobypay_api');

        $generated_signature = hash_hmac('sha256', $params, $api_key);

        return hash_equals($signature, $generated_signature);
    }

    public function json($data, $code=200) {
        for($i=0; $i<ob_get_status()['level']; $i++) ob_end_clean();
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode($data);
        die;
    }

    public function post($url, $data, $header=null) {
        $headers = Array();
        if ($header) {
            $headers = $header;
        }

        $headers[] = "User-Agent: Mobypay";
        $headers[] = "Content-Type: application/json";

        $opts = Array(
            "http" =>
                Array(
                    "method"  => "POST",
                    "header"  => $headers,
                    "content" => $data
                ),
            "ssl" => Array(
                "verify_peer" => false,
                "verify_peer_name" => false,
            ),
        );

        return file_get_contents($url, false, stream_context_create($opts));
    }
}



/*

function fill() {
    document.querySelector('[name=firstname]').value = 'Tuan';
    document.querySelector('[name=lastname]').value = 'Skaloot';
    document.querySelectorAll('[name=email]')[1].value = 'skaloot@mail.com';
    document.querySelector('[name=telephone]').value = '0101234567';
    document.querySelector('[name=address_1]').value = '123 Kenwingston Square Garden';
    document.querySelector('[name=city]').value = 'Cyberjaya';
    document.querySelector('[name=postcode]').value = '63000';
    document.querySelector('[name=country_id]').value = '129';
    change = new Event('change');
    document.querySelector('[name=country_id]').dispatchEvent(change);
    setTimeout(function() {
        document.querySelector('[name=zone_id]').value = '1983';
    }, 1000);
}
fill();

*/



