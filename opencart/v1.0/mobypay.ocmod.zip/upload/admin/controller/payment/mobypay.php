<?php

class ControllerPaymentMobypay extends Controller {

    private $supported_currency = array('MYR');
    private $version = '1.5.2';
    private $mobypay_register_account_url = 'https://app.mobypay.my/register';
    const MOBYPAY_API_DEVELOPMENT = 'https://dev.pay.mobycheckout.com';
    const MOBYPAY_API_PRODUCTION = 'https://pay.mobycheckout.com';
    const MOBYPAY_MAX_INSTALLMENT = 6;

    public function index() {
        $extensionMobypay = 'payment/mobypay';
        $this->load->language($extensionMobypay);

        $this->document->setTitle($this->language->get('heading_title'));

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'separator' => '',
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'separator' => ' :: ',
            'text' => $this->language->get('text_payment'),
            'href' => $this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL')
        );
        
        $data['breadcrumbs'][] = array(
            'separator' => ' :: ',
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('payment/mobypay', 'token=' . $this->session->data['token'], 'SSL')
        );

        if (isset($this->request->post['mobypay_title'])) {
            $data['mobypay_title'] = $this->request->post['mobypay_title'];
        } else {
            $data['mobypay_title'] = $this->config->get('mobypay_title') ? $this->config->get('mobypay_title') : 'Mobypay';
        }

        if (isset($this->request->post['mobypay_test_mode'])) {
            $data['mobypay_test_mode'] = $this->request->post['mobypay_test_mode'];
        } else {
            $data['mobypay_test_mode'] = $this->config->get('mobypay_test_mode');
        }

        if (isset($this->request->post['mobypay_client_id'])) {
            $data['mobypay_client_id'] = $this->request->post['mobypay_client_id'];
        } else {
            $data['mobypay_client_id'] = $this->config->get('mobypay_client_id');
        }

        if (isset($this->request->post['mobypay_api'])) {
            $data['mobypay_api'] = $this->request->post['mobypay_api'];
        } else {
            $data['mobypay_api'] = $this->config->get('mobypay_api');
        }

        if (isset($this->request->post['mobypay_status'])) {
            $data['mobypay_status'] = $this->request->post['mobypay_status'];
        } else {
            $data['mobypay_status'] = $this->config->get('mobypay_status');
        }

        if (isset($this->request->post['mobypay_description'])) {
            $data['mobypay_description'] = $this->request->post['mobypay_description'];
        } else {
            $data['mobypay_description'] = $this->config->get('mobypay_description');
        }

        if (isset($this->request->post['mobypay_paid_status_id'])) {
            $data['mobypay_paid_status_id'] = $this->request->post['mobypay_paid_status_id'];
        } else {
            $data['mobypay_paid_status_id'] = $this->config->get('mobypay_paid_status_id');
        }          

        if (isset($this->request->post['mobypay_rejected_status_id'])) {
            $data['mobypay_rejected_status_id'] = $this->request->post['mobypay_rejected_status_id'];
        } else {
            $data['mobypay_rejected_status_id'] = $this->config->get('mobypay_rejected_status_id');
        }

        if (isset($this->request->post['mobypay_refunded_status_id'])) {
            $data['mobypay_refunded_status_id'] = $this->request->post['mobypay_refunded_status_id'];
        } else {
            $data['mobypay_refunded_status_id'] = $this->config->get('mobypay_refunded_status_id');
        }

        if (isset($this->request->post['mobypay_sort_order'])) {
            $data['mobypay_sort_order'] = $this->request->post['mobypay_sort_order'];
            if ($this->request->post['mobypay_sort_order'] == '') $this->request->post['mobypay_sort_order'] = '1';
        } else {
            $data['mobypay_sort_order'] = $this->config->get('mobypay_sort_order');
            if ($data['mobypay_sort_order'] == '') $data['mobypay_sort_order'] = '1';
        }

        if (isset($this->request->post['mobypay_geo_zone_id'])) {
            $data['mobypay_geo_zone_id'] = $this->request->post['mobypay_geo_zone_id'];
        } else {
            $data['mobypay_geo_zone_id'] = (int)$this->config->get('mobypay_geo_zone_id');
        }

        if (isset($this->request->post['mobypay_currency'])) {
            $data['mobypay_currency'] = $this->request->post['mobypay_currency'];
        } else {
            $data['mobypay_currency'] = implode(', ', $this->supported_currency);
        }

        if (isset($this->request->post['mobypay_show_price_divider'])) {
            $data['mobypay_show_price_divider'] = $this->request->post['mobypay_show_price_divider'];
        } else {
            $data['mobypay_show_price_divider'] = $this->config->get('mobypay_show_price_divider');
        }

        if (isset($this->request->post['mobypay_min_product_price'])) {
            $data['mobypay_min_product_price'] = $this->request->post['mobypay_min_product_price'];
        } else {
            $data['mobypay_min_product_price'] = $this->config->get('mobypay_min_product_price');
        }

        if (isset($this->request->post['mobypay_show_in_product'])) {
            $data['mobypay_show_in_product'] = $this->request->post['mobypay_show_in_product'];
        } else {
            $data['mobypay_show_in_product'] = $this->config->get('mobypay_show_in_product');
        }

        if (isset($this->request->post['mobypay_show_in_category'])) {
            $data['mobypay_show_in_category'] = $this->request->post['mobypay_show_in_category'];
        } else {
            $data['mobypay_show_in_category'] = $this->config->get('mobypay_show_in_category');
        }

        if (isset($this->request->post['mobypay_show_in_cart'])) {
            $data['mobypay_show_in_cart'] = $this->request->post['mobypay_show_in_cart'];
        } else {
            $data['mobypay_show_in_cart'] = $this->config->get('mobypay_show_in_cart');
        }

        $data['mobypay_version'] = $this->version;
        $data['mobypay_register_account_url'] = $this->mobypay_register_account_url;

        $this->load->model('localisation/order_status');
        $this->load->model('localisation/geo_zone');

        $data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();
        $data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();
        $data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();
        $data['save'] = $this->url->link($extensionMobypay, 'token=' . $this->session->data['token'], 'SSL');
        $data['cancel'] = $this->url->link('extension/payment', 'token=' . $_GET['token'].'&type=payment');

        $this->template = 'payment/mobypay.tpl';
        $this->children = array(
            'common/header',
            'common/footer',
        );

        $data['header']      = $this->language->get('heading_title');
        $data['user_token']  = $_GET['token'];
        $data['success_msg']  = null;
        $data['error_msg'] = null;

        $data['heading_title'] = $this->language->get('heading_title');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_client_id'] = $this->language->get('text_client_id');
        $data['text_api_key'] = $this->language->get('text_api_key');
        $data['text_test_mode'] = $this->language->get('text_test_mode');
        $data['entry_order_status_paid'] = $this->language->get('entry_order_status_paid');
        $data['entry_order_status_rejected'] = $this->language->get('entry_order_status_rejected');
        $data['entry_order_status_refunded'] = $this->language->get('entry_order_status_refunded');
        $data['text_show_price_divider'] = $this->language->get('text_show_price_divider');
        $data['text_min_product_price'] = $this->language->get('text_min_product_price');
        $data['text_show_in'] = $this->language->get('text_show_in');
        $data['text_show_in_product'] = $this->language->get('text_show_in_product');
        $data['text_show_in_category'] = $this->language->get('text_show_in_category');
        $data['text_show_in_cart'] = $this->language->get('text_show_in_cart');
        $data['text_sort'] = $this->language->get('text_sort');;

        /* ------------------------ SAVE ------------------------ */
        if (($this->request->server['REQUEST_METHOD'] == 'POST')) {
            return $this->save($data);
        }

        $this->data = $data;
        $this->response->setOutput($this->render());
    }

    public function save($data) {
        $extensionMobypay = 'payment/mobypay';
        $this->load->language($extensionMobypay);

        $str = '<div style="display:inline-block;"><div style="display:flex;align-items:center;"><span>Moby Checkout</span>';
        $this->db->query("UPDATE `".DB_PREFIX."order` SET `payment_method` = 'Moby Checkout' WHERE `payment_method` like '".$str."%'");

        /* ------------------------ PERSMISSIOM ------------------------ */
        if (!$this->user->hasPermission('modify', $extensionMobypay)) {
            $data['error_msg'] = $this->language->get('error_permission');
        } else {
            /* ------------------------ VALIDATE FORM ------------------------ */
            if (empty($this->request->post['mobypay_api']) || empty($this->request->post['mobypay_client_id'])) {
                $data['error_msg'] = $this->language->get('text_error_enable_incomplete');
            } else {
                $api_key = $this->request->post['mobypay_api'];
                $client_id = $this->request->post['mobypay_client_id'];
                $current_client_id = $this->config->get('mobypay_client_id');
                $current_api_key = $this->config->get('mobypay_api');
                $mobypay_test_mode = $this->request->post['mobypay_test_mode'];

                if ($current_client_id !== $client_id || $current_api_key !== $api_key || $mobypay_test_mode == '0') {
                    $live_error = null; $dev_error = null;
                    $live_token = null; $dev_token = null;
                    /* ------------------------ GET PRODUCTION TOKEN ------------------------ */
                    try {
                        $live_token = $this->validateToken($api_key, $client_id);
                    } catch(\Exception $e) {
                        $live_error = $e->getMessage();
                        if ($live_error === '') $live_error = null;
                    }
                    /* ------------------------ GET DEVELOPMENT TOKEN - IGNORE ERROR ------------------------ */
                    try {
                        $dev_token = $this->validateToken($api_key, $client_id, true);
                    } catch(\Exception $e) {
                        $dev_error = $e->getMessage();
                        if ($dev_error === '') $dev_error = null;
                    }

                    /* ------------------------ EITHER LIVE OR STAGING MUST HAS TOKEN ------------------------ */
                    if (!$live_token && !$dev_token) {
                        $data['error_msg'] = ($live_error) ? $live_error : $dev_error;
                        $this->request->post['mobypay_status'] = 0;
                    }

                    /* ------------------------ LIVE MODE MUST HAS LIVE TOKEN ------------------------ */
                    if ($mobypay_test_mode == '0' && !$live_token) {
                        $data['error_msg'] = ($live_error) ? $live_error : $dev_error;
                        $this->request->post['mobypay_status'] = 0;
                    }
                }
            }

            /* ------------------------ MIN PRICE & INSTALLMENT ------------------------ */
            if ($this->request->post['mobypay_min_product_price'] !== '') {
                $this->request->post['mobypay_min_product_price'] = str_replace([' '], [''], $this->request->post['mobypay_min_product_price']);
                $this->request->post['mobypay_min_product_price'] = rtrim($this->request->post['mobypay_min_product_price'], ',');
                $this->request->post['mobypay_min_product_price'] = ltrim($this->request->post['mobypay_min_product_price'], ',');

                if (strpos($this->request->post['mobypay_min_product_price'], ':') === false) {
                    $data['error_msg'] = $this->language->get('text_error_mobypay_min_product_price');
                } elseif (preg_match('/[a-z]/i', $this->request->post['mobypay_min_product_price'])) {
                    $data['error_msg'] = $this->language->get('text_error_mobypay_min_product_price');
                } else {
                    $mobypay_min_product_price = explode(',', $this->request->post['mobypay_min_product_price']);
                    foreach($mobypay_min_product_price as $_price) {
                        if (strpos($_price, ':') === false) {
                            $data['error_msg'] = $this->language->get('text_error_mobypay_min_product_price');
                        } else {
                            list($price, $installment) = explode(':', trim($_price));
                            if (empty($installment) || !is_numeric($installment)) {
                                $data['error_msg'] = $this->language->get('text_error_mobypay_min_product_price');
                            } elseif ($installment > self::MOBYPAY_MAX_INSTALLMENT) {
                                $data['error_msg'] = $this->language->get('text_error_mobypay_min_product_price_max');
                            } elseif ($installment < 2) {
                                $data['error_msg'] = $this->language->get('text_error_mobypay_min_product_price_min');
                            }
                        }
                    }
                }
            }

            /* ------------------------ ALL GOOD ------------------------ */
            if (empty($data['error_msg'])) {
                $this->load->model('setting/setting');
                $this->model_setting_setting->editSetting('mobypay', $this->request->post);
                $data['success_msg'] = $this->language->get('text_success');
            }
        }

        $this->data = $data;
        $this->response->setOutput($this->render());
    }

    public function validateToken($mobypayApi, $mobypayClientID, $test=false) {
        $payload['clientId'] = $mobypayClientID;
        $payload['secretKey'] = $mobypayApi;

        $url = $this->getUrl($test).'/api/auth/token';
        $response = json_decode($this->post($url, json_encode($payload)));

        if (!empty($response->error)) {
            throw new Exception($response->msg ? $response->msg : $response->error);
        } elseif (empty($response->token)) {
            throw new Exception('');
        }

        return $response->token;
    }

    public function getUrl($test) {
        if ($test) {
            $url = self::MOBYPAY_API_DEVELOPMENT;
        } else {
            $url = self::MOBYPAY_API_PRODUCTION;
        }

        return $url;
    }

    public function post($url, $data, $header=null) {
        $headers = Array();
        if ($header) {
            $headers = $header;
        }

        $headers[] = "Content-Type: application/json";

        $http = curl_init();
        curl_setopt($http, CURLOPT_POST, 1);
        curl_setopt($http, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($http, CURLOPT_TIMEOUT, 10);
        curl_setopt($http, CURLOPT_HTTPHEADER, $headers);

        curl_setopt($http, CURLOPT_URL, $url);
        curl_setopt($http, CURLOPT_POSTFIELDS, $data);
        $response = curl_exec($http);
        $httpStatusCode = curl_getinfo($http, CURLINFO_HTTP_CODE);
        curl_close($http);

        if ($httpStatusCode == 200) {
            if (trim($response) == '') {
                $response = [
                    'error' => 'no_response_data',
                    'msg' => 'API_ERROR : No Response Data From Moby.'
                ];
            }
        } else {
            $response = [
                'error' => 'connect_error',
                'msg' => 'API_ERROR ' . $httpStatusCode . ' : Cannot Connect To Moby Server.'
            ];
        }
      
        return $response;
    }


}
