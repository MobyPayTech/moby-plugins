<?php

$files = [
	['/upload/admin/controller/payment/mobypay.php', '/../admin/controller/payment/mobypay.php'],
	['/upload/admin/language/english/payment/mobypay.php', '/../admin/language/english/payment/mobypay.php'],
	['/upload/admin/view/image/payment/mobypay.png', '/../admin/view/image/payment/mobypay.png'],
	['/upload/admin/view/stylesheet/mobypay.css', '/../admin/view/stylesheet/mobypay.css'],
	['/upload/admin/view/template/payment/mobypay.tpl', '/../admin/view/template/payment/mobypay.tpl'],
	
	['/upload/catalog/controller/payment/mobypay.php', '/../catalog/controller/payment/mobypay.php'],
	['/upload/catalog/language/english/payment/mobypay.php', '/../catalog/language/english/payment/mobypay.php'],
	['/upload/catalog/model/payment/mobypay.php', '/../catalog/model/payment/mobypay.php'],
	['/upload/catalog/view/theme/default/image/mobypay.png', '/../catalog/view/theme/default/image/mobypay.png'],
	['/upload/catalog/view/theme/default/image/mobypay-moby-islamic-logo.png', '/../catalog/view/theme/default/image/mobypay-moby-islamic-logo.png'],
	['/upload/catalog/view/theme/default/image/mobypay-shop-favorite.png', '/../catalog/view/theme/default/image/mobypay-shop-favorite.png'],
	['/upload/catalog/view/theme/default/image/mobypay-split-payment.png', '/../catalog/view/theme/default/image/mobypay-split-payment.png'],
	['/upload/catalog/view/theme/default/image/mobypay-we-pay-first.png', '/../catalog/view/theme/default/image/mobypay-we-pay-first.png'],
	['/upload/catalog/view/theme/default/image/mobypay-zero-intersest.png', '/../catalog/view/theme/default/image/mobypay-zero-intersest.png'],
	['/upload/catalog/view/theme/default/template/payment/mobypay.tpl', '/../catalog/view/theme/default/template/payment/mobypay.tpl'],
	['/upload/vqmod/xml/mobypay.xml', '/../vqmod/xml/mobypay.xml'],
];

echo 'Files :<br>';
foreach($files as $file) {
	copy(__DIR__.$file[0], __DIR__.$file[1]) or die('Error : '.substr($file[1], 3).' is not writable');
	echo substr($file[1], 3).'<br>';
}

echo 'Done';