<?php

namespace Opencart\Catalog\Model\Extension\Mobypay\Payment;

class Mobypay extends \Opencart\System\Engine\Model
{
    public function getMethods(array $address): array
    {
        $this->load->language('extension/mobypay/payment/mobypay');

        $methodData = [
            'code'      => 'mobypay',
            'name'      => $this->language->get('heading_title'),
            'sort_order' => $this->config->get('payment_mobypay_sort_order'),
            'option'    => [
                'mobypay' => [
                    'code' => 'mobypay.mobypay',
                    'name' => $this->language->get('heading_title'),
                ]
            ],
        ];

        return $methodData;

    }


}
