# Moby Checkout Opencart 4

# App uses :
-   PHP

# Tech :
- backend PHP

# Install :
```shell
git clone git@github.com:MobyPayTech/moby-checkout-opencart4.git
cd moby-checkout-opencart4/
zip ./* mobypay.ocmod.zip
```



