<?php

namespace Opencart\Admin\Controller\Extension\Mobypay\Payment;
use \Exception;

class Mobypay extends \Opencart\System\Engine\Controller
{

    private $supported_currency = ['MYR'];
    private $version = '4.0.1';
    private $mobypay_register_account_url = 'https://app.mobypay.my/register';
    const MOBYPAY_API_DEVELOPMENT = 'https://dev.pay.mobycheckout.com';
    const MOBYPAY_API_PRODUCTION = 'https://pay.mobycheckout.com';

    public function index(): void
    {
        $extensionMobypay = 'extension/mobypay/payment/mobypay';
        $this->load->language($extensionMobypay);

        $this->document->setTitle($this->language->get('heading_title'));
        $data['breadcrumbs'] = [];

        $userToken = 'user_token=';

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', $userToken.$this->session->data['user_token']),
        ];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', $userToken.$this->session->data['user_token'].'&type=payment'),
        ];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link($extensionMobypay, $userToken.$this->session->data['user_token']),
        ];

        if (isset($this->request->post['payment_mobypay_title'])) {
            $data['payment_mobypay_title'] = $this->request->post['payment_mobypay_title'];
        } else {
            $data['payment_mobypay_title'] = $this->config->get('payment_mobypay_title') ? $this->config->get('payment_mobypay_title') : 'Mobypay';
        }

        if (isset($this->request->post['payment_mobypay_test_mode'])) {
            $data['payment_mobypay_test_mode'] = $this->request->post['payment_mobypay_test_mode'];
        } else {
            $data['payment_mobypay_test_mode'] = $this->config->get('payment_mobypay_test_mode');
        }

        if (isset($this->request->post['payment_mobypay_client_id'])) {
            $data['payment_mobypay_client_id'] = $this->request->post['payment_mobypay_client_id'];
        } else {
            $data['payment_mobypay_client_id'] = $this->config->get('payment_mobypay_client_id');
        }

        if (isset($this->request->post['payment_mobypay_api'])) {
            $data['payment_mobypay_api'] = $this->request->post['payment_mobypay_api'];
        } else {
            $data['payment_mobypay_api'] = $this->config->get('payment_mobypay_api');
        }

        if (isset($this->request->post['payment_mobypay_status'])) {
            $data['payment_mobypay_status'] = $this->request->post['payment_mobypay_status'];
        } else {
            $data['payment_mobypay_status'] = $this->config->get('payment_mobypay_status');
        }

        if (isset($this->request->post['payment_mobypay_description'])) {
            $data['payment_mobypay_description'] = $this->request->post['payment_mobypay_description'];
        } else {
            $data['payment_mobypay_description'] = $this->config->get('payment_mobypay_description');
        }

        if (isset($this->request->post['payment_mobypay_paid_status_id'])) {
            $data['payment_mobypay_paid_status_id'] = $this->request->post['payment_mobypay_paid_status_id'];
        } else {
            $data['payment_mobypay_paid_status_id'] = $this->config->get('payment_mobypay_paid_status_id');
        }          

        if (isset($this->request->post['payment_mobypay_rejected_status_id'])) {
            $data['payment_mobypay_rejected_status_id'] = $this->request->post['payment_mobypay_rejected_status_id'];
        } else {
            $data['payment_mobypay_rejected_status_id'] = $this->config->get('payment_mobypay_rejected_status_id');
        }

        if (isset($this->request->post['payment_mobypay_refunded_status_id'])) {
            $data['payment_mobypay_refunded_status_id'] = $this->request->post['payment_mobypay_refunded_status_id'];
        } else {
            $data['payment_mobypay_refunded_status_id'] = $this->config->get('payment_mobypay_refunded_status_id');
        }

        if (isset($this->request->post['payment_mobypay_sort_order'])) {
            $data['payment_mobypay_sort_order'] = $this->request->post['payment_mobypay_sort_order'];
            if ($this->request->post['payment_mobypay_sort_order'] == '') $this->request->post['payment_mobypay_sort_order'] = '1';
        } else {
            $data['payment_mobypay_sort_order'] = $this->config->get('payment_mobypay_sort_order');
            if ($data['payment_mobypay_sort_order'] == '') $data['payment_mobypay_sort_order'] = '1';
        }

        if (isset($this->request->post['payment_mobypay_geo_zone_id'])) {
            $data['payment_mobypay_geo_zone_id'] = $this->request->post['payment_mobypay_geo_zone_id'];
        } else {
            $data['payment_mobypay_geo_zone_id'] = (int)$this->config->get('payment_mobypay_geo_zone_id');
        }

        if (isset($this->request->post['payment_mobypay_currency'])) {
            $data['payment_mobypay_currency'] = $this->request->post['payment_mobypay_currency'];
        } else {
            $data['payment_mobypay_currency'] = implode(', ', $this->supported_currency);
        }

        $data['payment_mobypay_version'] = $this->version;
        $data['mobypay_register_account_url'] = $this->mobypay_register_account_url;

        $this->load->model('localisation/order_status');
        $this->load->model('localisation/geo_zone');

        $data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();
        $data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();
        $data['save'] = $this->url->link($extensionMobypay.'|save', $userToken.$this->session->data['user_token']);
        $data['back'] = $this->url->link('marketplace/extension', $userToken.$this->session->data['user_token'].'&type=payment');

        $data['header']      = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer']      = $this->load->controller('common/footer');

        $path = explode('/', str_replace('/admin/controller/payment/mobypay.php', '', __FILE__));
        $extension_name = $path[count($path) - 1];
        $data['logo'] = '/extension/'.$extension_name.'/assets/images/logo.png';
        $data['css'] = '/extension/'.$extension_name.'/assets/stylesheet/mobypay.css';

        $this->response->setOutput($this->load->view($extensionMobypay, $data));
    }

    public function save(): void
    {
        $extensionMobypay = 'extension/mobypay/payment/mobypay';
        $this->load->language($extensionMobypay);

        $json = [];
        if (!$this->user->hasPermission('modify', $extensionMobypay)) {
            $json['error'] = $this->language->get('error_permission');
        } else {
            if (empty($this->request->post['payment_mobypay_api']) || empty($this->request->post['payment_mobypay_client_id'])) {
                $json['error'] = $this->language->get('text_error_enable_incomplete');
            } else {
                $api_key = $this->request->post['payment_mobypay_api'];
                $client_id = $this->request->post['payment_mobypay_client_id'];
                $current_client_id = $this->config->get('payment_mobypay_client_id');
                $current_api_key = $this->config->get('payment_mobypay_api');

                if ($current_client_id !== $client_id || $current_api_key !== $api_key) {
                    $live_error = null; $dev_error = null;
                    $live_token = null; $dev_token = null;
                    $json['changed'] = true;
                    
                    /* -------------------- GET PRODUCTION TOKEN -------------------- */
                    try {
                        $live_token = $this->validateToken($api_key, $client_id);
                    } catch(\Exception $e) {
                        $live_error = $e->getMessage();
                        if ($live_error === '') $live_error = null;
                    }
                    /* -------------------- GET DEVELOPMENT TOKEN - IGNORE ERROR -------------------- */ 
                    try {
                        $dev_token = $this->validateToken($api_key, $client_id, true);
                    } catch(\Exception $e) {
                        $dev_error = $e->getMessage();
                        if ($dev_error === '') $dev_error = null;
                    }

                    /* -------------------- EITHER LIVE OR STAGING MUST HAS TOKEN -------------------- */
                    if (!$live_token && !$dev_token) {
                        $json['error'] = $live_error ?? $dev_error;
                    }
                }
            }

            /* -------------------- ALL GOOD -------------------- */
            if (empty($json['error'])) {
                $this->load->model('setting/setting');
                $this->model_setting_setting->editSetting('payment_mobypay', $this->request->post);
                $json['success'] = $this->language->get('text_success');
            }
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function validateToken($mobypayApi, $mobypayClientID, $test=false): mixed
    {
        $payload['clientId'] = $mobypayClientID;
        $payload['secretKey'] = $mobypayApi;

        $url = $this->getUrl($test).'/api/auth/token';
        $response = json_decode($this->post($url, json_encode($payload)));

        if (!empty($response->error)) {
            throw new Exception($response->msg ?? $response->error);
        } elseif (empty($response->token)) {
            throw new Exception('');
        }

        return $response->token;
    }

    public function getUrl($test): string
    {
        if ($test) {
            $url = self::MOBYPAY_API_DEVELOPMENT;
        } else {
            $url = self::MOBYPAY_API_PRODUCTION;
        }

        return $url;
    }

    public function post($url, $data, $header=null): string
    {
        $curl = curl_init();
        $options = [
            CURLOPT_TIMEOUT => 5,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_URL => $url,
            CURLOPT_USERAGENT => 'Moby Checkout',
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $data
        ];

        if (!$header) $header = [];
        $header[] = "Content-Type: application/json";
        $options[CURLOPT_HTTPHEADER] = $header;

        curl_setopt_array($curl, $options);
        $resp = curl_exec($curl);
        curl_close($curl);

        return $resp;
    }


}
