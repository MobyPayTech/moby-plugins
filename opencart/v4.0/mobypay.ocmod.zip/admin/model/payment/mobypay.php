<?php

namespace Opencart\Admin\Model\Extension\Mobypay\Payment;

class Mobypay extends \Opencart\System\Engine\Model
{

}

