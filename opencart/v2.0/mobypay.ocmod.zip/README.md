# Moby Checkout Opencart 2

# App uses :
-   PHP

# Tech :
- backend PHP

# Install :
```shell
git clone git@github.com:MobyPayTech/moby-checkout-opencart1.git
cd moby-checkout-opencart1/
zip ./* mobypay.ocmod.zip
```


