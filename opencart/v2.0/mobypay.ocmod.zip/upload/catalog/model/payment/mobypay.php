<?php

class ModelPaymentMobypay extends Controller {

    public function getCurrency() {
        return array('MYR');
    }

    public function getMethod($address, $total) {
        $this->load->language('payment/mobypay');
        
        $methodData = array(
            'code'       => 'mobypay',
            'title'      => $this->language->get('text_title'),
            'terms'      => '',
            'sort_order' => $this->config->get('mobypay_sort_order')
        );

        return $methodData;

    }


}
