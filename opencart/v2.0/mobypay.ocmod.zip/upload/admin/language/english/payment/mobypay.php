<?php

$_['heading_title']      = 'Moby Checkout';
$_['text_payment']		 = 'Payments';
$_['text_enabled']       = 'Enabled';
$_['text_disabled']      = 'Disabled';
$_['text_test_mode']	 = 'Test Mode';
$_['text_client_id']     = 'Merchant ID';
$_['text_api_key']		 = 'API Key';
$_['text_title']         = 'Title';
$_['text_description']   = 'Description';
$_['entry_status']       = 'Status:';
$_['text_button_save']   = 'Save';
$_['text_button_cancel'] = 'Cancel';
$_['text_sort'] 		 = 'Sort Order';
$_['text_success']       = 'Success: You have modified your Mobypay payment module!';
$_['text_error_enable_incomplete']       = 'Error: Please provide API Key and Client ID to enable this extension';
$_['text_edit']          = 'Edit Mobypay Merchant Credential';
$_['text_mobypay']		 = '<a href="https://app.mobypay.my" target="_blank"><img src="view/image/payment/mobypay.png" alt="Moby Checkout" title="Moby Checkout" style="height:30px;" /></a>';


$_['entry_order_status']			= 'Pending Status';
$_['entry_order_status_paid'] 		= 'Paid Status';
$_['entry_order_status_rejected'] 	= 'Rejected Status';
$_['entry_order_status_cancelled'] 	= 'Cancelled Status';
$_['entry_order_status_refunded'] 	= 'Refunded Status';