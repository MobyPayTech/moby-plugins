<?php

class ControllerPaymentMobypay extends Controller {

    private $supported_currency = array('MYR');
    private $version = '2.0.1';
    private $mobypay_register_account_url = 'https://app.mobypay.my/register';
    const MOBYPAY_API_DEVELOPMENT = 'https://dev.pay.mobycheckout.com';
    const MOBYPAY_API_PRODUCTION = 'https://pay.mobycheckout.com';

    public function index() {
        $extensionMobypay = 'payment/mobypay';
        $this->load->language($extensionMobypay);

        $this->document->setTitle($this->language->get('heading_title'));

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_payment'),
            'href' => $this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL')
        );
        
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('payment/mobypay', 'token=' . $this->session->data['token'], 'SSL')
        );

        if (isset($this->request->post['mobypay_title'])) {
            $data['mobypay_title'] = $this->request->post['mobypay_title'];
        } else {
            $data['mobypay_title'] = $this->config->get('mobypay_title') ? $this->config->get('mobypay_title') : 'Mobypay';
        }

        if (isset($this->request->post['mobypay_test_mode'])) {
            $data['mobypay_test_mode'] = $this->request->post['mobypay_test_mode'];
        } else {
            $data['mobypay_test_mode'] = $this->config->get('mobypay_test_mode');
        }

        if (isset($this->request->post['mobypay_client_id'])) {
            $data['mobypay_client_id'] = $this->request->post['mobypay_client_id'];
        } else {
            $data['mobypay_client_id'] = $this->config->get('mobypay_client_id');
        }

        if (isset($this->request->post['mobypay_api'])) {
            $data['mobypay_api'] = $this->request->post['mobypay_api'];
        } else {
            $data['mobypay_api'] = $this->config->get('mobypay_api');
        }

        if (isset($this->request->post['mobypay_status'])) {
            $data['mobypay_status'] = $this->request->post['mobypay_status'];
        } else {
            $data['mobypay_status'] = $this->config->get('mobypay_status');
        }

        if (isset($this->request->post['mobypay_description'])) {
            $data['mobypay_description'] = $this->request->post['mobypay_description'];
        } else {
            $data['mobypay_description'] = $this->config->get('mobypay_description');
        }

        if (isset($this->request->post['mobypay_paid_status_id'])) {
            $data['mobypay_paid_status_id'] = $this->request->post['mobypay_paid_status_id'];
        } else {
            $data['mobypay_paid_status_id'] = $this->config->get('mobypay_paid_status_id');
        }          

        if (isset($this->request->post['mobypay_rejected_status_id'])) {
            $data['mobypay_rejected_status_id'] = $this->request->post['mobypay_rejected_status_id'];
        } else {
            $data['mobypay_rejected_status_id'] = $this->config->get('mobypay_rejected_status_id');
        }

        if (isset($this->request->post['mobypay_refunded_status_id'])) {
            $data['mobypay_refunded_status_id'] = $this->request->post['mobypay_refunded_status_id'];
        } else {
            $data['mobypay_refunded_status_id'] = $this->config->get('mobypay_refunded_status_id');
        }

        if (isset($this->request->post['mobypay_sort_order'])) {
            $data['mobypay_sort_order'] = $this->request->post['mobypay_sort_order'];
            if ($this->request->post['mobypay_sort_order'] == '') $this->request->post['mobypay_sort_order'] = '1';
        } else {
            $data['mobypay_sort_order'] = $this->config->get('mobypay_sort_order');
            if ($data['mobypay_sort_order'] == '') $data['mobypay_sort_order'] = '1';
        }

        if (isset($this->request->post['mobypay_geo_zone_id'])) {
            $data['mobypay_geo_zone_id'] = $this->request->post['mobypay_geo_zone_id'];
        } else {
            $data['mobypay_geo_zone_id'] = (int)$this->config->get('mobypay_geo_zone_id');
        }

        if (isset($this->request->post['mobypay_currency'])) {
            $data['mobypay_currency'] = $this->request->post['mobypay_currency'];
        } else {
            $data['mobypay_currency'] = implode(', ', $this->supported_currency);
        }

        $data['mobypay_version'] = $this->version;
        $data['mobypay_register_account_url'] = $this->mobypay_register_account_url;

        $this->load->model('localisation/order_status');
        $this->load->model('localisation/geo_zone');

        $data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();
        $data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();
        $data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();
        $data['save'] = $this->url->link($extensionMobypay, 'token=' . $this->session->data['token'], 'SSL');
        $data['cancel'] = $this->url->link('extension/payment', 'token=' . $_GET['token'].'&type=payment');

        // echo json_encode($data['geo_zones']); die;

        $data['header']      = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer']      = $this->load->controller('common/footer');
        $data['user_token']  = $_GET['token'];
        $data['success_msg']  = null;
        $data['error_msg'] = null;

        $data['heading_title'] = $this->language->get('heading_title');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_client_id'] = $this->language->get('text_client_id');
        $data['text_api_key'] = $this->language->get('text_api_key');
        $data['text_test_mode'] = $this->language->get('text_test_mode');
        $data['entry_order_status_paid'] = $this->language->get('entry_order_status_paid');
        $data['entry_order_status_rejected'] = $this->language->get('entry_order_status_rejected');
        $data['entry_order_status_refunded'] = $this->language->get('entry_order_status_refunded');
        $data['text_sort'] = $this->language->get('text_sort');

        /* ------------------------ SAVE ------------------------ */
        if (($this->request->server['REQUEST_METHOD'] == 'POST')) {
            return $this->save($data);
        }

        $this->document->setTitle($this->language->get('heading_title_main'));
        $this->response->setOutput($this->load->view($extensionMobypay.'.tpl', $data));
    }

    public function save($data) {
        $extensionMobypay = 'payment/mobypay';
        $this->load->language($extensionMobypay);

        $this->db->query("UPDATE `".DB_PREFIX."order` SET `payment_method` = 'Moby Checkout' WHERE `payment_method` != 'Moby Checkout' AND `payment_code` = 'mobypay'");

        /* ------------------------ PERSMISSIOM ------------------------ */
        if (!$this->user->hasPermission('modify', $extensionMobypay)) {
            $data['error_msg'] = $this->language->get('error_permission');
        } else {
            /* ------------------------ VALIDATE FORM ------------------------ */
            if (empty($this->request->post['mobypay_api']) || empty($this->request->post['mobypay_client_id'])) {
                $data['error_msg'] = $this->language->get('text_error_enable_incomplete');
            } else {
                $api_key = $this->request->post['mobypay_api'];
                $client_id = $this->request->post['mobypay_client_id'];
                $current_client_id = $this->config->get('mobypay_client_id');
                $current_api_key = $this->config->get('mobypay_api');

                if ($current_client_id !== $client_id || $current_api_key !== $api_key) {
                    $live_error = null; $dev_error = null;
                    $live_token = null; $dev_token = null;
                    /* ------------------------ GET PRODUCTION TOKEN ------------------------ */
                    try {
                        $live_token = $this->validateToken($api_key, $client_id);
                    } catch(\Exception $e) {
                        $live_error = $e->getMessage();
                        if ($live_error === '') $live_error = null;
                    }
                    /* ------------------------ GET DEVELOPMENT TOKEN - IGNORE ERROR ------------------------ */
                    try {
                        $dev_token = $this->validateToken($api_key, $client_id, true);
                    } catch(\Exception $e) {
                        $dev_error = $e->getMessage();
                        if ($dev_error === '') $dev_error = null;
                    }

                    /* ------------------------ EITHER LIVE OR STAGING MUST HAS TOKEN ------------------------ */
                    if (!$live_token && !$dev_token) {
                        $data['error_msg'] = ($live_error) ? $live_error : $dev_error;
                        $this->request->post['mobypay_status'] = 0;
                    }
                }

                /* ------------------------ ALL GOOD ------------------------ */
                if (!$data['error_msg']) {
                    $this->load->model('setting/setting');
                    $this->model_setting_setting->editSetting('mobypay', $this->request->post);
                    $data['success_msg'] = $this->language->get('text_success');
                }
            }
        }

        $this->document->setTitle($this->language->get('heading_title_main'));
        $this->response->setOutput($this->load->view($extensionMobypay.'.tpl', $data));
    }

    public function validateToken($mobypayApi, $mobypayClientID, $test=false) {
        $payload['clientId'] = $mobypayClientID;
        $payload['secretKey'] = $mobypayApi;

        $url = $this->getUrl($test).'/api/auth/token';
        $response = json_decode($this->post($url, json_encode($payload)));

        if (!empty($response->error)) {
            throw new Exception($response->msg ? $response->msg : $response->error);
        } elseif (empty($response->token)) {
            throw new Exception('');
        }

        return $response->token;
    }

    public function getUrl($test) {
        if ($test) {
            $url = self::MOBYPAY_API_DEVELOPMENT;
        } else {
            $url = self::MOBYPAY_API_PRODUCTION;
        }

        return $url;
    }

    public function post($url, $data, $header=null) {
        $curl = curl_init();
        $options = array(
            CURLOPT_TIMEOUT => 5,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_URL => $url,
            CURLOPT_USERAGENT => 'Mobypay',
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $data
        );

        if (!$header) $header = array();
        $header[] = "Content-Type: application/json";
        $options[CURLOPT_HTTPHEADER] = $header;

        curl_setopt_array($curl, $options);
        $resp = curl_exec($curl);
        curl_close($curl);

        return $resp;
    }


}
