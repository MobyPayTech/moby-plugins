<?php

class ModelPaymentMobypay extends Model {


}

