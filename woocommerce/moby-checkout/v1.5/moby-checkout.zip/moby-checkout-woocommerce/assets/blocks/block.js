window.addEventListener('load', function (e) {
  (function (registry, element) {
    if (registry && element) {
      const el = element.createElement;
      const { registerPaymentMethod } = registry;
      const labelLogoConfig = [
        {
          enabled: mobypay_data?.show_visa_logo,
          src: mobypay_data?.plugin_url + '/assets/images/visa.svg',
          alt: 'Visa'
        },
        {
          enabled: mobypay_data?.show_mastercard_logo,
          src: mobypay_data?.plugin_url + '/assets/images/mastercard.svg',
          alt: 'Mastercard'
        },
        {
          enabled: mobypay_data?.show_maybank_logo,
          src: mobypay_data?.plugin_url + '/assets/images/maybank.png',
          alt: 'Maybank'
        },
        {
          enabled: mobypay_data?.show_fpx_logo,
          src: mobypay_data?.plugin_url + '/assets/images/fpx.svg',
          alt: 'FPX'
        }
      ];
      const labelLogoItems = labelLogoConfig
        .filter((logo) => Boolean(logo.enabled))
        .map((logo, index) =>
          el('img', {
            src: logo.src,
            alt: logo.alt,
            style: {
              height: '24px',
              width: 'auto',
              display: 'block',
              marginLeft: index === 0 ? '12px' : '0'
            }
          })
        );
      const labelChildren = [
        'Moby Checkout',
        labelLogoItems.length
          ? el(
              'span',
              {
                style: {
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '0'
                }
              },
              labelLogoItems
            )
          : null
      ].filter(Boolean);

      const options = {
        name: 'moby-checkout',
        title: 'Moby Checkout Widget',
        paymentMethodId: 'moby-checkout',
        ariaLabel: 'Moby Checkout',
        canMakePayment: () => true,
        supports: {
          features: ['products'],
        },

        content: el(
          'div',
          {
            className: 'moby-checkout-description',
            style: {
              padding: '12px 14px',
              borderRadius: '12px',
              border: '1px solid #d9e2ec',
              background: 'linear-gradient(135deg, #f8fbff 0%, #eef6ff 100%)',
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
              color: '#12304a',
              fontSize: '14px'
            }
          },
          [
            el(
              'div',
              {
                style: {
                  width: '44px',
                  height: '44px',
                  borderRadius: '10px',
                  background: 'transparent',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }
              },
              [
                el('img', {
                  src: mobypay_data.plugin_url + '/assets/images/logo2.png',
                  alt: 'Moby Checkout',
                  style: {
                    maxHeight: '40px',
                    width: 'auto',
                    display: 'block'
                  },
                  onError: (event) => {
                    event.target.parentNode.style.background = '#0f6ecd';
                    const fallback = event.target.parentNode?.querySelector('.moby-logo-fallback');
                    if (fallback) fallback.style.display = 'flex';
                    event.target.style.display = 'none';
                  }
                }),
                el(
                  'span',
                  {
                    className: 'moby-logo-fallback',
                    style: {
                      color: '#ffffff',
                      fontWeight: '700',
                      fontSize: '16px',
                      display: 'none'
                    }
                  },
                  'M'
                )
              ]
            ),
            el(
              'div',
              { style: { display: 'flex', flexDirection: 'column', gap: '2px' } },
              [
                el(
                  'div',
                  { style: { fontWeight: '600', fontSize: '15px' } },
                  'Moby Checkout'
                ),
                el(
                  'div',
                  { style: { color: '#20568a' } },
                  'Pay securely and earn up to 10% cashback on this order.'
                )
              ]
            ),
            el(
              'span',
              {
                style: {
                  marginLeft: 'auto',
                  padding: '4px 8px',
                  borderRadius: '999px',
                  background: '#0f6ecd',
                  color: '#ffffff',
                  fontSize: '12px',
                  fontWeight: '600'
                }
              },
              'Cashback'
            )
          ]
        ),

        edit: el(
          'div',
          { className: 'moby-checkout-preview' },
          'Moby Checkout (Preview in Editor)'
        ),

        label: el(
          'span',
          { style: { fontWeight: '600', display: 'inline-flex', alignItems: 'center' } },
          labelChildren
        ),
      };

      console.log('MOBYPAY Blocks V2 loaded');
      registerPaymentMethod(options);
    }
  })(window.wc?.wcBlocksRegistry, window.wp?.element);
});
