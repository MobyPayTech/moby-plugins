

(function() {
    const name = 'mobypay-checkout';

    console.log(name + ' loaded..');

    window.addEventListener('load', function() {
    	const style = document.querySelector('#mobypay-checkout-css');
    	if (style) document.head.appendChild(style);
    });
})();
