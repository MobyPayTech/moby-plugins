<?php


class Payment {

    const MOBYPAY_API_DELEOPMENT = 'https://dev.pay.mobycheckout.com';
    const MOBYPAY_API_PRODUCTION = 'https://pay.mobycheckout.com';
    const MERCHANT_DEFAULT_TOKEN_ERROR_MSG = 'There is a problem with your Moby Checkout account. Please check your Merchant ID and API Key';
    const PUBLIC_DEFAULT_TOKEN_ERROR_MSG = 'There is a problem with merchant\'s account';

    public static function create($options) {
        $order = $options['order'];
        $order_id = (string)$order['order_id']; 
        $payload['clientId'] = $options['merchant_id'];
        $payload['customerName'] = $order['billing']['first_name'];
        $payload['customerName'] .= ' '.$order['billing']['last_name'];
        $payload['customerEmail'] = $order['billing']['email'] ?? '';
        $payload['customerMobile'] = $order['billing']['phone'] ?? '+60100000000';
        $payload['referenceNo'] = $order_id;
        $payload['details'] = 'Order #'.$order_id;
        $payload['amount'] = $order['total'];
        $payload['callbackUrl'] = $options['callback_url'];
        $payload['returnUrl'] = $options['return_url'];
        $payload['additionalInfo'] = [
            'order_id' => $order_id,
            'cart' => $order['cart']
        ];

        $mobypay_api = self::getMobypayApi($options);
        $token = self::getToken($options);
        
        if (empty($token->token)) {
            if ($options['test']) {
                $msg = 'Merchant does not has a test account';
            } else {
                $msg = self::PUBLIC_DEFAULT_TOKEN_ERROR_MSG;
            }

            return (object) ['error'=>true,'msg'=>$msg];
        }


        $header = ['Authorization: Bearer '.$token->token];
        $url = $mobypay_api.'/api/merchant/payment/checkout/hosted';
        $response = json_decode(Curl::post($url, json_encode($payload), $header));

        return $response;
    }

    public static function refund($options) {
        $order = $options['order'];

        $payload['clientId'] = $options['merchant_id'];
        $payload['referenceNo'] = (string)$order['order_id'];
        $payload['amount'] = $options['amount'];
        $payload['callback_url'] = $options['callback_url'];
        
        $mobypay_api = self::getMobypayApi($options);
        $token = self::getToken($options);
        if (empty($token->token)) return (object) ['error'=>true,'msg'=>$token->msg ?? self::MERCHANT_DEFAULT_TOKEN_ERROR_MSG];
        $header = ['Authorization: Bearer '.$token->token];
        $url = $mobypay_api.'/api/merchant/payment/refund';
        $response = json_decode(Curl::post($url, json_encode($payload), $header));

        return $response;
    }

    public static function getMobypayApi($options) {
        if ($options['test']) {
            $mobypay_api = self::MOBYPAY_API_DELEOPMENT;
        } else {
            $mobypay_api = self::MOBYPAY_API_PRODUCTION;
        }

        return $mobypay_api;
    }

    public static function getToken($options) {
        $mobypay_api = self::getMobypayApi($options);

        $payload['clientId'] = $options['merchant_id'];
        $payload['secretKey'] = $options['api_key'];

        $url = $mobypay_api.'/api/auth/token';
        $response = json_decode(Curl::post($url, json_encode($payload)));

        return $response ?? null;
    }


}









