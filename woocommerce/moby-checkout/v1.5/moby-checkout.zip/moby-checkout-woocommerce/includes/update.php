<?php

require_once __DIR__ . '/curl.php';
if (!function_exists('curl_version')) die('Mobypay : Curl is not installed.');

check_version();

function check_version() {
	if (!is_writable(MOBYPAY_PLUGIN_DIR)) die('Mobypay : '.MOBYPAY_PLUGIN_DIR.' is not writable');
	if (!is_writable(MOBYPAY_PLUGIN_ASSETS_DIR)) die('Mobypay : '.MOBYPAY_PLUGIN_ASSETS_DIR.' is not writable');
	if (!is_writable(__DIR__)) die('Mobypay : '.__DIR__.' is not writable');
	
	if (!file_exists(MOBYPAY_PLUGIN_DIR.'/version.txt')) {
		file_put_contents(MOBYPAY_PLUGIN_DIR.'/version.txt', '0.0.1');
	}
	if (!file_exists(MOBYPAY_PLUGIN_DIR.'/last_update.txt')) {
		file_put_contents(MOBYPAY_PLUGIN_DIR.'/last_update.txt', '2023-01-01');
	}

	$last_update = file_get_contents(MOBYPAY_PLUGIN_DIR.'/last_update.txt');

	if ($last_update != date('Y-m-d')) {
		file_put_contents(MOBYPAY_PLUGIN_DIR.'/last_update.txt', date('Y-m-d'));
		$current_version = file_get_contents(MOBYPAY_PLUGIN_DIR.'/version.txt');
		$version = Curl::get(EXTENSION_HOST.'/moby-checkout-woocommerce/download.php?file=version.txt');
		if (Curl::$response_code !== 200) return;

		if ($current_version != $version) {
			file_put_contents(MOBYPAY_PLUGIN_DIR.'/version.txt', $version);
			$js = MOBYPAY_PLUGIN_ASSETS_DIR.'/js/mobypay-checkout.js';
			$css = MOBYPAY_PLUGIN_ASSETS_DIR.'/css/mobypay-checkout.css';
			$payment = __DIR__.'/payment.php';
			$mobypay_checkout = __DIR__.'/mobypay-checkout.php';
			$mobypay_checkout_gateway = __DIR__.'/mobypay-checkout-gateway.php';
			
			$new_js = (string) Curl::get(EXTENSION_HOST.'/moby-checkout-woocommerce/download.php?file=assets/js/mobypay-checkout.js');
			if (Curl::$response_code !== 200) return;
			$new_css = (string) Curl::get(EXTENSION_HOST.'/moby-checkout-woocommerce/download.php?file=assets/css/mobypay-checkout.css');
			if (Curl::$response_code !== 200) return;
			$new_payment = (string) Curl::get(EXTENSION_HOST.'/moby-checkout-woocommerce/download.php?file=includes/payment.php');
			if (Curl::$response_code !== 200) return;
			$new_mobypay_checkout = (string) Curl::get(EXTENSION_HOST.'/moby-checkout-woocommerce/download.php?file=includes/mobypay-checkout.php');
			if (Curl::$response_code !== 200) return;
			$new_mobypay_checkout_gateway = (string) Curl::get(EXTENSION_HOST.'/moby-checkout-woocommerce/download.php?file=includes/mobypay-checkout-gateway.php');
			if (Curl::$response_code !== 200) return;

			if ($new_js === '') return;
			if ($new_css === '') return;
			if ($new_payment === '') return;
			if ($new_mobypay_checkout === '') return;
			if ($new_mobypay_checkout_gateway === '') return;

			file_put_contents($js, $new_js);
			file_put_contents($css, $new_css);
			file_put_contents($payment, $new_payment);
			file_put_contents($mobypay_checkout, $new_mobypay_checkout);
			file_put_contents($mobypay_checkout_gateway, $new_mobypay_checkout_gateway);
		}
	}
}


