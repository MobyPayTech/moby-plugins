<?php

/**
 * Curl Class
 */
class Curl {

    public static $response_code;
    const APP_NAME = 'moby-checkout';

    static function post($url, $data, $header=null) {
        self::$response_code = 200;
        $curl = curl_init();
        $options = [
            CURLOPT_TIMEOUT => 5,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_URL => $url,
            CURLOPT_USERAGENT => self::APP_NAME,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $data
        ];

        if (!$header) $header = [];
        $header[] = "Content-Type: application/json";
        $options[CURLOPT_HTTPHEADER] = $header;

        curl_setopt_array($curl, $options);
        $resp = curl_exec($curl);
        self::$response_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);

        return $resp;
    }

    static function get($url, $header=null) {
        self::$response_code = 200;
        $curl = curl_init();
        $options = [
            CURLOPT_TIMEOUT => 5,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_URL => $url,
            CURLOPT_USERAGENT => self::APP_NAME,
            CURLOPT_CUSTOMREQUEST => "GET",
        ];

        if ($header) $options[CURLOPT_HTTPHEADER] = $header;

        curl_setopt_array($curl, $options);        
        $resp = curl_exec($curl);
        self::$response_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);

        return $resp;
    }

    static function put($url, $data, $header=null) {
        self::$response_code = 200;
        $data = http_build_query($data);

        $curl = curl_init();
        $options = [
            CURLOPT_TIMEOUT => 5,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_URL => $url,
            CURLOPT_USERAGENT => self::APP_NAME,
            CURLOPT_CUSTOMREQUEST => "PUT",
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $data
        ];

        if (!$header) $header = [];
        $header[] = 'Content-Type: application/x-www-form-urlencoded';
        $options[CURLOPT_HTTPHEADER] = $header;

        curl_setopt_array($curl, $options);        
        $resp = curl_exec($curl);
        self::$response_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);

        return $resp;
    }

    static function delete($url, $header=null) {
        self::$response_code = 200;
        $curl = curl_init();
        $options = [
            CURLOPT_TIMEOUT => 5,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_URL => $url,
            CURLOPT_USERAGENT => self::APP_NAME,
            CURLOPT_CUSTOMREQUEST => "DELETE",
        ];

        if ($header) $options[CURLOPT_HTTPHEADER] = $header;

        curl_setopt_array($curl, $options);    
        $resp = curl_exec($curl);
        self::$response_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);

        return $resp;
    }


}




