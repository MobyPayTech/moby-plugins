<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

/**
 * The mobypay-checkout class.
 */
class MobypayCheckoutBlocks extends AbstractPaymentMethodType {

	public $name = 'moby-checkout';

	public function initialize() {
		// echo '<script>console.log("Initialized");</script>';
		// $gateways = WC()->payment_gateways->get_available_payment_gateways();
		// echo json_encode($gateways); die;
	}

	public function is_active() {
		return true;
	}

	public function get_payment_method_script_handles() {
		return Array();
	}

	public function get_script_data() {
		return Array();
	}

	public function get_payment_method_data() {
		return array(
			'title'       => 'Moby Checkout',
			'description' => 'Moby Checkout',
			'supports'    => Array(
				'products'
			),
		);
	}

	public function get_name() {
		return $this->name;
	}

	public function get_script_handles() {
		return Array(
			'mobypay-checkout'
		);
	}

	public function get_supported_features() {
		$gateways = WC()->payment_gateways->get_available_payment_gateways();
		if ( isset( $gateways['mobypay-checkout'] ) ) {
			return $gateways['mobypay-checkout']->supports;
		}
		return array();
	}
}

