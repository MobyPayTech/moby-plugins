<?php

/**
 * Plugin Name: Moby Checkout
 * Plugin URI: https://ecom-plugin.mobycheckout.com/
 * Description: Moby Checkout offers a seamless payment experience for both you and your customers. With a user-friendly interface and easy integration, you can start accepting payments quickly and efficiently.
 * Version: 2.0.0
 * Author: Mobypay
 * Author URI: https://app.mobypay.my
 * Text Domain: mobypay
 *
 * @package extension
 */

defined('EXTENSION_HOST') || define('EXTENSION_HOST', 'https://ecom-plugin.mobycheckout.com');
defined('MOBYPAY_PLUGIN_DIR') || define('MOBYPAY_PLUGIN_DIR', __DIR__);
defined('MOBYPAY_PLUGIN_ASSETS_DIR') || define('MOBYPAY_PLUGIN_ASSETS_DIR', __DIR__.'/assets');
defined('MOBYPAY_PLUGIN_FILE') || define('MOBYPAY_PLUGIN_FILE', plugin_basename(__FILE__));

add_action('before_woocommerce_init', function(){
    if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
    }
});

// require_once plugin_dir_path(__FILE__) . 'includes/update.php';
require_once plugin_dir_path(__FILE__) . 'includes/curl.php';
require_once plugin_dir_path(__FILE__) . 'includes/mobypay-checkout.php';


