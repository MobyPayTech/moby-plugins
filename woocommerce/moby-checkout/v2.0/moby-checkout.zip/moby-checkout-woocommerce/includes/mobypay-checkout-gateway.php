<?php

defined('ABSPATH') || exit;

use JetBrains\PhpStorm\NoReturn;

require_once plugin_dir_path(__FILE__).'payment.php';

if (class_exists('MobypayCheckoutGateway')) {
    return;
}

/**
 * MobypayCheckoutGateway Class
 */
class MobypayCheckoutGateway extends WC_Payment_Gateway
{

    /** Default cashback percentage advertised on the checkout label. */
    const DEFAULT_CASHBACK_PERCENTAGE = 10;

    public $title = '';
    public $description = '';
    public $enabled = '';
    public $testmode = false;
    public $api_key = '';
    public $merchant_id = '';
    public $merchant_name = '';
    public $icon = '';
    public $show_visa_logo = '';
    public $show_mastercard_logo = '';
    public $show_online_banking_logo = '';
    public $show_duitnow_logo = '';
    public $show_grabpay_logo = '';
    public $show_paylater_logo = '';
    public $show_cashback_logo = '';
    public $cashback_percentage = '';

    public function __construct()
    {
        $this->id = 'moby-checkout';
        $this->has_fields = true;
        $this->method_title = __('Moby Checkout', 'moby-payment-gateway');
        $this->method_description = __('Moby Checkout offers a seamless payment experience for both you and your customers. With a user-friendly interface and easy integration, you can start accepting payments quickly and efficiently.', 'mobypay-payment-gateway');

        $this->supports = array(
            'products',
            // 'refunds', DISABLE FOR NOW
        );

        $this->init_form_fields();
        $this->init_settings();

        $this->title = 'Moby';
        $this->description = '';
        $this->enabled = $this->get_option('enabled');
        $this->testmode = 'test' === $this->get_option('mode');
        $this->api_key = $this->get_option('api_key');
        $this->merchant_id = $this->get_option('merchant_id');
        $this->merchant_name = $this->get_option('company_name');
        $this->icon = '';
        $this->show_visa_logo = $this->get_option('show_visa_logo');
        $this->show_mastercard_logo = $this->get_option('show_mastercard_logo');
        $this->show_online_banking_logo = $this->get_option('show_online_banking_logo');
        $this->show_duitnow_logo = $this->get_option('show_duitnow_logo');
        $this->show_grabpay_logo = $this->get_option('show_grabpay_logo');
        $this->show_paylater_logo = $this->get_option('show_paylater_logo');
        $this->show_cashback_logo = $this->get_option('show_cashback_logo');
        $this->cashback_percentage = $this->get_cashback_percentage();

        add_action('woocommerce_update_options_payment_gateways_'.$this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_api_'.$this->id, array($this, 'mobypay_callback'));
        add_action('woocommerce_thankyou', array($this, 'mobypay_response'));
    }

    /**
     * Payment-method logos enabled by default. Each entry maps a setting key to
     * its image file and accessible label. Mirrors assets/blocks/block.js.
     */
    public static function label_logos()
    {
        return array(
            'show_visa_logo' => array('visa.png', 'Visa'),
            'show_mastercard_logo' => array('mastercard.png', 'Mastercard'),
            'show_online_banking_logo' => array('online_bank.png', 'Online Banking'),
            'show_duitnow_logo' => array('duitnow.png', 'DuitNow'),
            'show_grabpay_logo' => array('grab_pay.png', 'GrabPay'),
            'show_paylater_logo' => array('pay_later.png', 'Pay Later'),
        );
    }

    /**
     * Merchant-configured cashback percentage (defaults to 10).
     */
    public function get_cashback_percentage()
    {
        $value = (int) $this->get_option('cashback_percentage', self::DEFAULT_CASHBACK_PERCENTAGE);
        if ($value <= 0 || $value > 100) {
            $value = self::DEFAULT_CASHBACK_PERCENTAGE;
        }
        return $value;
    }

    /**
     * Logos shown next to the method title on the classic checkout label.
     * Mirrors the label logos rendered by assets/blocks/block.js.
     */
    public function get_icon()
    {
        $base = plugins_url('../assets/images', __FILE__);

        $enabled = array();
        foreach (self::label_logos() as $option => $logo) {
            if ('yes' === $this->get_option($option)) {
                $enabled[] = $logo;
            }
        }
        $show_cashback = 'yes' === $this->get_option('show_cashback_logo');
        $count = count($enabled);

        $icon = '';
        foreach ($enabled as $i => $logo) {
            $ml = 0 === $i ? '12px' : '8px';
            $mr = ($show_cashback && $i === $count - 1) ? '16px' : '0';
            $icon .= '<img src="'.esc_url($base.'/'.$logo[0]).'" alt="'.esc_attr($logo[1]).'" onerror="this.style.display=\'none\'" style="height:28px !important;width:auto !important;display:inline-block !important;vertical-align:middle !important;margin-inline-start:'.$ml.' !important;margin-inline-end:'.$mr.' !important;" />';
        }

        if ($show_cashback) {
            $icon .= $this->cashback_badge_html($count ? '' : '12px');
        }

        return apply_filters('woocommerce_gateway_icon', $icon, $this->id);
    }

    /**
     * Cashback badge rebuilt as inline-styled markup (mirrors cashback.png):
     * a gold rounded pill with the merchant percentage over a "Cashback" label.
     */
    public function cashback_badge_html($margin_left = '')
    {
        $percentage = $this->get_cashback_percentage();
        $margin = '' !== $margin_left ? 'margin-inline-start:'.esc_attr($margin_left).' !important;' : '';

        return '<span style="display:inline-flex !important;align-items:center !important;justify-content:center !important;gap:2px !important;line-height:1 !important;vertical-align:middle !important;'.$margin.'height:24px !important;padding:0 9px !important;border-radius:12px !important;background:linear-gradient(180deg,#FCC419 0%,#F0A800 100%) !important;color:#3a2c00 !important;box-shadow:0 1px 2px rgba(0,0,0,0.2) !important;">'
            .'<span style="font-size:12px !important;font-weight:600 !important;">'.esc_html($percentage).'%</span>'
            .'<span style="font-size:11px !important;font-weight:600 !important;letter-spacing:0.2px !important;">'.esc_html__('Cashback', 'mobypay').'</span>'
            .'</span>';
    }

    /**
     * No expandable content is shown on the classic checkout when the method is
     * selected — the logos and cashback badge live on the label itself.
     */
    public function payment_fields()
    {
    }

    public function process_admin_options()
    {
        $merchant_id = trim($_POST['woocommerce_moby-checkout_merchant_id'] ?? '');
        $api_key = trim($_POST['woocommerce_moby-checkout_api_key'] ?? '');
        $error_msg = null;

        /* --------------------------- IF VALUE EMPTY --------------------------- */
        if ($merchant_id === '' || $api_key === '') {
            unset($_POST['woocommerce_moby-checkout_enabled']);
            $_POST['woocommerce_moby-checkout_merchant_id'] = $this->settings['merchant_id'];
            $_POST['woocommerce_moby-checkout_api_key'] = $this->settings['api_key'];
            $error_msg = 'Please provide your Mobypay credential to enable this extension.';
        } else {
            /* --------------------------- VERIFY TOKEN ONLY IF THERES CHANGES --------------------------- */
            if ($this->settings['merchant_id'] != $merchant_id || $this->settings['api_key'] != $api_key) {
                $live_token = null;
                $dev_token = null;
                $live_error = null;
                $dev_error = null;

                /* --------------------------- LIVE TOKEN --------------------------- */
                $options['test'] = false;
                $options['merchant_id'] = $merchant_id;
                $options['api_key'] = $api_key;
                $response = Mobypay_Payment::getToken($options);

                if (empty($response->token)) {
                    $live_error = $response->msg ?? $response->error ?? null;
                } else {
                    $live_token = $response->token;
                }

                /* --------------------------- DEV TOKEN --------------------------- */
                $options['test'] = true;
                $options['merchant_id'] = $merchant_id;
                $options['api_key'] = $api_key;
                $response = Mobypay_Payment::getToken($options);

                if (empty($response->token)) {
                    $dev_error = $response->msg ?? $response->error ?? null;
                } else {
                    $dev_token = $response->token;
                }

                /* --------------------------- IF NO TOKEN --------------------------- */
                if (! $live_token && ! $dev_token) {
                    unset($_POST['woocommerce_moby-checkout_enabled']);
                    $error_msg = $live_error ?? $dev_error ?? 'Something went wrong';
                }
            }
        }

        /* --------------------------- PRODUCE WOOCOMMERCE ERROR --------------------------- */
        if ($error_msg) {
            add_action('admin_notices', function () use ($error_msg) {
                $message = '<div class="notice notice-error is-dismissible"><p>'.$error_msg.'</p></div>';
                $message .= '<script>(function() {';
                $message .= 'const s = document.createElement("STYLE");';
                $message .= 's.innerHTML = "#message { display:none; }";';
                $message .= 'document.head.appendChild(s);';
                $message .= '})();</script>';
                echo $message;
            }, 10);
        }

        parent::process_admin_options();

        return true;
    }

    public function init_form_fields()
    {
        $this->form_fields = array(
            'enabled' => array(
                'title' => __('Enable', 'mobypay-payment-gateway'),
                'type' => 'checkbox',
                'description' => '',
                'default' => 'no',
            ),
            'mode' => array(
                'title' => __('Environment', 'mobypay-payment-gateway'),
                'type' => 'select',
                'description' => __('Test mode allow you to test the plugin without processing money, make sure you set the plugin to live mode and click on "Save changes" for real customers to use it', 'mobypay-payment-gateway'),
                'default' => 'Test',
                'options' => array(
                    'live' => __('Production Mode', 'mobypay-payment-gateway'),
                    'test' => __('Sandbox Mode', 'mobypay-payment-gateway')
                )
            ),
            'merchant_id' => array(
                'title' => __('Merchant ID', 'mobypay-payment-gateway'),
                'type' => 'text',
                'description' => __('Please refer to your Mobypay account.', 'mobypay-payment-gateway'),
            ),
            'api_key' => array(
                'title' => __('API Key', 'mobypay-payment-gateway'),
                'type' => 'text',
                'description' => __('Please refer to your Mobypay account.', 'mobypay-payment-gateway'),
            ),
            'company_name' => array(
                'title' => __('Company Name', 'mobypay-payment-gateway'),
                'type' => 'text',
                'description' => __('Company Name.', 'mobypay-payment-gateway'),
            ),
            'show_visa_logo' => array(
                'title' => __('Show Visa logo', 'mobypay-payment-gateway'),
                'type' => 'checkbox',
                'label' => __('Display the Visa logo next to the checkout label', 'mobypay-payment-gateway'),
                'default' => 'yes',
            ),
            'show_mastercard_logo' => array(
                'title' => __('Show Mastercard logo', 'mobypay-payment-gateway'),
                'type' => 'checkbox',
                'label' => __('Display the Mastercard logo next to the checkout label', 'mobypay-payment-gateway'),
                'default' => 'yes',
            ),
            'show_online_banking_logo' => array(
                'title' => __('Show online banking logo', 'mobypay-payment-gateway'),
                'type' => 'checkbox',
                'label' => __('Display the online banking logo next to the checkout label', 'mobypay-payment-gateway'),
                'default' => 'yes',
            ),
            'show_duitnow_logo' => array(
                'title' => __('Show DuitNow logo', 'mobypay-payment-gateway'),
                'type' => 'checkbox',
                'label' => __('Display the DuitNow logo next to the checkout label', 'mobypay-payment-gateway'),
                'default' => 'yes',
            ),
            'show_grabpay_logo' => array(
                'title' => __('Show GrabPay logo', 'mobypay-payment-gateway'),
                'type' => 'checkbox',
                'label' => __('Display the GrabPay logo next to the checkout label', 'mobypay-payment-gateway'),
                'default' => 'yes',
            ),
            'show_paylater_logo' => array(
                'title' => __('Show Pay Later logo', 'mobypay-payment-gateway'),
                'type' => 'checkbox',
                'label' => __('Display the Pay Later logo next to the checkout label', 'mobypay-payment-gateway'),
                'default' => 'yes',
            ),
            'show_cashback_logo' => array(
                'title' => __('Show cashback logo', 'mobypay-payment-gateway'),
                'type' => 'checkbox',
                'label' => __('Display the cashback badge next to the checkout label', 'mobypay-payment-gateway'),
                'default' => 'yes',
            ),
            'cashback_percentage' => array(
                'title' => __('Cashback percentage', 'mobypay-payment-gateway'),
                'type' => 'number',
                'description' => __('Cashback percentage shown on the cashback badge (1-100).', 'mobypay-payment-gateway'),
                'default' => (string) self::DEFAULT_CASHBACK_PERCENTAGE,
                'custom_attributes' => array(
                    'min' => '1',
                    'max' => '100',
                    'step' => '1',
                ),
            ),
        );
    }

    public function process_payment($order_id)
    {
        global $woocommerce;
        $pay_for_order = $_GET['pay_for_order'] ?? null;

        if (! $pay_for_order) {
            WC()->session->__unset('order_id');
        }

        $o = wc_get_order($order_id);

        if (! $o) {
            return [];
        }

        /* --------------------------- CURRENCY ONLY MYR --------------------------- */
        if ($o->get_currency() != 'MYR') {
            $this->setMessages('Currency must be in MYR', 'error');
            return [];
        }

        if (! $pay_for_order) {
            WC()->session->set('order_id', $order_id);
        }
        $order = $o->get_data();

        /* --------------------------- CONSTRUCT CART DATA --------------------------- */
        $order['cart']['items'] = [];
        $order['cart']['amount'] = $order['total'];
        $items = $o->get_items();
        foreach ($items as $k => $item) {
            $product = $item->get_product();
            $order['cart']['items'][] = [
                'product' => [
                    'id' => $product->get_id(),
                    'title' => $product->get_name(),
                    'price' => number_format($product->get_price(), 2),
                ],
                'amount' => $item->get_total(),
                'quantity' => $item->get_quantity()
            ];
        }

        /* --------------------------- RETURN URL --------------------------- */
        $return_url = $this->get_return_url($o);
        $return_url .= '&mobypay_order_id='.$order_id;
        $return_url .= '&type=payment&';

        $callback_url = wc_get_endpoint_url('wc-api/moby-checkout', '', wc_get_page_permalink(''));
        $callback_url .= '?mobypay_order_id='.$order_id;
        $callback_url .= '&type=payment';

        /* --------------------------- PREPARE PAYLOAD --------------------------- */
        $options['order'] = $order;
        $options['order']['order_id'] = $order_id;
        $options['test'] = $this->testmode;
        $options['merchant_id'] = $this->merchant_id;
        $options['api_key'] = $this->api_key;
        $options['return_url'] = $return_url;
        $options['callback_url'] = $callback_url;
        $options['store_name'] = $this->merchant_name;
        $payment = Mobypay_Payment::create($options);

        /* --------------------------- HANDLE ERROR --------------------------- */
        if (! empty($payment->error)) {
            $this->setMessages($payment->msg ?? $payment->error, 'error');
            return [];
        }
        if (empty($payment->payLink)) {
            $this->setMessages('Mobypay is experiencing an error at the moment.', 'error');
            return [];
        }

        /* --------------------------- DET REDIRECT IF PAY FROM ORDER PAGE --------------------------- */
        if ($pay_for_order) {
            header("location: {$payment->payLink}");
            return [];
        }

        return [
            'result' => 'success',
            'redirect' => $payment->payLink
        ];
    }

    public function process_refund($order_id, $amount = null, $reason = '')
    {
        $o = wc_get_order($order_id);
        $order = $o->get_data();

        if ($order['status'] == 'refunded') {
            new WP_Error('error', __('Order already refunded.', 'woocommerce'));
            return false;
        }
        if ($amount === '0.00') {
            new WP_Error('error', __('Amount cannot be empty.', 'woocommerce'));
            return false;
        }
        if (! $this->can_refund_order($o)) {
            new WP_Error('error', __('Order cannot be refunded.', 'woocommerce'));
            return false;
        }

        $callback_url = wc_get_endpoint_url('wc-api/moby-checkout', '', wc_get_page_permalink(''));
        $callback_url .= '?mobypay_order_id='.$order_id;
        $callback_url .= '&type=refund';

        $options['amount'] = $amount;
        $options['order'] = $order;
        $options['test'] = $this->testmode;
        $options['merchant_id'] = $this->merchant_id;
        $options['api_key'] = $this->api_key;
        $options['callback_url'] = $callback_url;
        $options['store_name'] = $this->merchant_name;
        $refund = Mobypay_Payment::refund($options);

        if (! empty($refund->error) && ! empty($refund->msg)) {
            $o->add_order_note(__('Mobypay : '.$refund->msg, 'woocommerce'));
            new WP_Error('error', __($refund->msg, 'woocommerce'));
            return false;
        } else {
            $o->add_order_note(__('Mobypay : Refund request is being processed.', 'woocommerce'));
            return true;
        }
    }

    public function request()
    {
        // Capture raw request body
        $request_body = file_get_contents('php://input');

        // Parse JSON data if the content type is application/json
        $json_data = [];
        if (isset($_SERVER['CONTENT_TYPE']) && strpos($_SERVER['CONTENT_TYPE'], 'application/json') !== false) {
            $json_data = json_decode($request_body, true) ?? [];
        }

        // Merge all possible input sources
        return array_merge($_GET, $_POST, $json_data);
    }

    public function mobypay_callback()
    {
        $data = $this->request();
        $transaction_id = $data['transactionId'] ?? null;
        $status = $data['status'] ?? null;
        $type = $data['type'] ?? 'payment';
        $mobypay_order_id = $data['mobypay_order_id'] ?? null;

        if (! $status) {
            $this->response(['error' => 'Status is missing.', 'status' => 'failed']);
        }

        if (! $mobypay_order_id) {
            $this->response(['error' => 'Mobypay order id is missing.', 'status' => 'failed']);
        }

        if (! $transaction_id) {
            $this->response(['error' => 'Transaction id is missing.', 'status' => 'failed']);
        }

        $order = wc_get_order($mobypay_order_id);

        if (! $this->validate_hmac()) {
            $order->add_order_note(__("Mobypay : Signature invalid", 'woocommerce'));

            $this->response(['error' => 'HMAC mismatch', 'status' => 'failed']);
        }

        if ($type == 'payment') {
            if (! $order->has_status('processing') && ! $order->has_status('completed')) {
                if ($status == 'success') {
                    $order->add_order_note(__("Mobypay payment success. Transaction ID : {$transaction_id}", 'woocommerce'));
                    $order->payment_complete($transaction_id);
                } elseif ($status == 'failed') {
                    $order->add_order_note(__("Mobypay payment failed. Transaction ID : {$transaction_id}", 'woocommerce'));
                } elseif ($status == 'cancelled') {
                    $order->add_order_note(__("Mobypay payment cancelled. Transaction ID : {$transaction_id}", 'woocommerce'));
                } elseif ($status == 'processing') {
                    $order->add_order_note(__("Mobypay payment is being processed", 'woocommerce'));
                }
            }
        } elseif ($type == 'refund') {
            if (! $order->has_status('refunded')) {
                if ($status == 'success') {
                    $order->update_status('refunded', __("Mobypay refund success. Transaction ID : {$transaction_id}", 'woocommerce'));
                }
            }
        }

        $this->response(['message' => 'Callback received successfully', 'status' => 'success']);
    }

    public function response($data): void
    {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data);
        exit;
    }

    public function mobypay_response($order_id)
    {
        $transaction_id = $_GET['transactionId'] ?? $_GET['?transactionId'] ?? '';
        $status = $_GET['status'] ?? $_GET['?status'] ?? null;
        $type = $_GET['type'] ?? 'payment';
        $mobypay_order_id = $_GET['mobypay_order_id'] ?? null;

        if (! $mobypay_order_id) {
            return '';
        }

        $order = wc_get_order($mobypay_order_id);

        /* --------------------------- SUCCESS MSG --------------------------- */
        $success = <<<SCRIPT
        <script>
            const msg = document.querySelector('.woocommerce-notice');
            if (msg) {
                msg.innerHTML = 'Thank you. Your payment has been successful.';
                msg.classList.add('mobypay-success-message');
            }
        </script>
        SCRIPT;

        /* --------------------------- ERROR MSG --------------------------- */
        $error = <<<SCRIPT
        <script>
            let msg = document.querySelector('.woocommerce-notice');
            if(!msg){
                msg = document.querySelector('.wc-block-order-confirmation-status');
            }
            console.log('msg', msg);
            if (msg) {
                msg.innerHTML = 'Sorry. Your payment has been unsuccessful.';
                msg.classList.add('mobypay-error-message');
            }
        </script>
        SCRIPT;

        /* --------------------------- SET PAYMENT METHOD LABEL --------------------------- */
        $logo = <<<SCRIPT
        <script>
            const method = document.querySelector('.woocommerce-order-overview__payment-method');
            if (method) {
                method.innerHTML = 'Payment Method';
                method.innerHTML += '<strong>Moby Checkout</strong>';
            }
        </script>
        SCRIPT;

        echo $logo;

        if (! $order) {
            return '';
        }
        /* --------------------------- VALIDATE HMAC SIGNATURE --------------------------- */
        if (! $this->validate_hmac()) {
            echo $error;
            return $order->add_order_note(__("Mobypay : Signature invalid", 'woocommerce'));
        }

        /* --------------------------- UPDATE ORDER STATUS --------------------------- */
        if ($type == 'payment') {
            if (! $order->has_status('processing') && ! $order->has_status('completed')) {
                if ($status == 'success') {
                    echo $success;
                    $order->add_order_note(__("Mobypay payment success. Transaction ID : {$transaction_id}", 'woocommerce'));
                    $order->payment_complete($transaction_id);
                } elseif ($status == 'failed') {
                    echo $error;
                    $order->add_order_note(__("Mobypay payment failed. Transaction ID : {$transaction_id}", 'woocommerce'));
                } elseif ($status == 'cancelled') {
                    echo $error;
                    $order->add_order_note(__("Mobypay payment cancelled. Transaction ID : {$transaction_id}", 'woocommerce'));
                } elseif ($status == 'processing') {
                    echo $error;
                    $order->add_order_note(__("Mobypay payment is being processed", 'woocommerce'));
                } else {
                    echo $error;
                }
            }
        } elseif ($type == 'refund') {
            if (! $order->has_status('refunded')) {
                if ($status == 'success') {
                    echo $success;
                    $order->update_status('refunded', __("Mobypay refund success. Transaction ID : {$transaction_id}", 'woocommerce'));
                }
            }
        }
        return '';
    }

    public function validate_hmac()
    {
        $params = $this->request();
        $signature = $params['signature'] ?? '';
        $referenceNo = $params['referenceNo'] ?? '';
        unset($params['signature']);
        unset($params['key']);
        unset($params['mobypay_order_id']);
        unset($params['type']);
        unset($params['?referenceNo']);
        $params['referenceNo'] = $referenceNo;

        if (
            ! isset($params['referenceNo']) ||
            ! isset($params['transactionId']) ||
            ! isset($params['amount']) ||
            ! isset($params['payMethod']) ||
            ! isset($params['status'])
        ) {
            return false;
        }

        ksort($params);
        $stringSign = implode('', $params);
        $api_key = $this->get_option('api_key');
        $generated_signature = hash_hmac('sha256', $stringSign, $api_key);
        return hash_equals($signature, $generated_signature);
    }

    private function setMessages($message = '', $class = '')
    {
        global $woocommerce;

        if (function_exists('wc_add_notice')) {
            wc_add_notice($message, $class);
        } else {
            if ('success' == $class) {
                $woocommerce->add_message($message);
            } else {
                $woocommerce->add_error($message);
            }

            $woocommerce->set_messages();
        }
    }
}
