<?php

defined('ABSPATH') || exit;
use Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry;
use Automattic\WooCommerce\Blocks\Integrations\IntegrationInterface;

if (!defined('MAIN_PLUGIN_FILE')) {
	define('MAIN_PLUGIN_FILE', __FILE__);
}

add_filter('woocommerce_available_payment_gateways', 'mobypay_is_available', 1);
add_action('wp_enqueue_scripts', 'mobypay_register_scripts');
add_filter('plugin_action_links_'.MOBYPAY_PLUGIN_FILE, 'mobypay_add_settings_link');



if (!function_exists('mobypay_is_available')) {
function mobypay_is_available($gateway_list) {
    if (get_option('woocommerce_currency') != 'MYR') {
        unset($gateway_list['mobypay-checkout']);
    }
    return $gateway_list;
}
}

if (!function_exists('mobypay_add_settings_link')) {
function mobypay_add_settings_link($links) {
    $links[] = '<a href="'.admin_url('admin.php?page=wc-settings&tab=checkout&section=moby-checkout').'">' . __('Settings') . '</a>';
    return $links;
}
}

if (!function_exists('mobypay_register_scripts')) {
function mobypay_register_scripts()
{
	wp_register_style('mobypay-checkout', plugins_url('../assets/css/mobypay-checkout.css', __FILE__));
	wp_enqueue_style('mobypay-checkout');
	wp_register_script('mobypay-checkout', plugins_url('../assets/js/mobypay-checkout.js', __FILE__));
	wp_enqueue_script('mobypay-checkout');

	wp_register_script('moby-checkout-block', plugins_url('../assets/blocks/block.js', __FILE__), array('wp-blocks'), '1.0.0', true);
	$gateway_settings = get_option('woocommerce_moby-checkout_settings', array());
	$is_on = function ($key, $default = 'yes') use ($gateway_settings) {
		$value = isset($gateway_settings[$key]) ? $gateway_settings[$key] : $default;
		return $value === 'yes';
	};
	$default_cashback = class_exists('MobypayCheckoutGateway') ? MobypayCheckoutGateway::DEFAULT_CASHBACK_PERCENTAGE : 10;
	$cashback_percentage = isset($gateway_settings['cashback_percentage']) ? (int) $gateway_settings['cashback_percentage'] : 0;
	if ($cashback_percentage <= 0 || $cashback_percentage > 100) {
		$cashback_percentage = $default_cashback;
	}
	wp_localize_script('moby-checkout-block', 'mobypay_data', array(
		'plugin_url' => plugins_url('', dirname(__FILE__)),
		'show_visa_logo' => $is_on('show_visa_logo'),
		'show_mastercard_logo' => $is_on('show_mastercard_logo'),
		'show_online_banking_logo' => $is_on('show_online_banking_logo'),
		'show_duitnow_logo' => $is_on('show_duitnow_logo'),
		'show_grabpay_logo' => $is_on('show_grabpay_logo'),
		'show_paylater_logo' => $is_on('show_paylater_logo'),
		'show_cashback_logo' => $is_on('show_cashback_logo'),
		'cashback_percentage' => $cashback_percentage,
	));
	wp_enqueue_script('moby-checkout-block');
}
}

if (!function_exists('mobypay_init')) {
function mobypay_init() {
	if (!class_exists('WooCommerce') || !class_exists('WC_Payment_Gateway')) {
		return;
	}

	$GLOBALS['MobypayCheckout'] = MobypayCheckout::instance();

	require_once plugin_dir_path(__FILE__) . 'mobypay-checkout-gateway.php';
	add_filter('woocommerce_payment_gateways', function($gateways) {
		if (!class_exists('WC_Payment_Gateway')) return;
		$gateways[] = 'MobypayCheckoutGateway';
		return $gateways;
	});
}
}

if (!function_exists('wc_mobypay_register_block')) {
function wc_mobypay_register_block() {
	if ( ! class_exists( 'Automattic\WooCommerce\Blocks\Package' ) ) return;

	require_once plugin_dir_path(__FILE__) . 'MobypayCheckoutBlocks.php';

	add_action('woocommerce_blocks_payment_method_type_registration', function(PaymentMethodRegistry $payment_method_registry) {
		$payment_method_registry->register( new MobypayCheckoutBlocks );

		$blocks_json = MOBYPAY_PLUGIN_DIR.'/block.json';
		$args = array(
			'frontend_script' => true,
			'backend_style'   => false,
			'frontend_style'  => false,
		);

		$plugin_root = MOBYPAY_PLUGIN_DIR;
		$path = explode('/', MOBYPAY_PLUGIN_DIR);
		$path = array_slice($path, -3);
		$plugin_url = '//'.$_SERVER['HTTP_HOST'].'/'.implode('/', $path);

		$script_helper_data = array( 'dependencies' => array('wp-blocks'),'version' => '0.1');
		wp_register_script( 'mobypay-checkout-editor', $plugin_url.'/assets/blocks/block.js', $script_helper_data['dependencies'], $script_helper_data['version'], true );

		$script_helper_data = array( 'dependencies' => array('wp-blocks'),'version' => '0.1');
		wp_register_script( 'mobypay-checkout', $plugin_url.'/assets/blocks/block.js', $script_helper_data['dependencies'], $script_helper_data['version'], true );

		$registry = register_block_type_from_metadata( $blocks_json, $args );
	});
}
}


if (!class_exists('MobypayCheckout')) {
	/**
	 * The mobypay-checkout class.
	 */
	class MobypayCheckout {
		/**
		 * This class instance.
		 *
		 * @var mixed
		 */
		private static $instance;
		private static $version = '1.0.0';

		/**
		 * Cloning is forbidden.
		 */
		public function __clone() {
			wc_doing_it_wrong(__FUNCTION__, __('Cloning is forbidden.', 'mobypay-checkout'), $this->version);
		}

		/**
		 * Unserializing instances of this class is forbidden.
		 */
		public function __wakeup() {
			wc_doing_it_wrong(__FUNCTION__, __('Unserializing instances of this class is forbidden.', 'mobypay-checkout'), $this->version);
		}

		/**
		 * Gets the main instance.
		 *
		 * Ensures only one instance can be loaded.
		 *
		 * @return \MobypayCheckout
		 */
		public static function instance() {
			if (self::$instance === null) {
				self::$instance = new self();
			}

			return self::$instance;
		}
	}
}

add_action('plugins_loaded', 'mobypay_init', 10);
add_action('woocommerce_blocks_loaded', 'wc_mobypay_register_block');
