window.addEventListener('load', function (e) {
  (function (registry, element) {
    if (registry && element) {
      const el = element.createElement;
      const { registerPaymentMethod } = registry;

      // React inline `style` objects cannot carry `!important`, so styles are
      // applied through a ref that calls setProperty(..., 'important'). This
      // hardens the label against merchant themes overriding our layout.
      const imp = (styles) => (node) => {
        if (!node) {
          return;
        }
        Object.keys(styles).forEach(function (prop) {
          node.style.setProperty(prop, styles[prop], 'important');
        });
      };

      const labelLogoConfig = [
        {
          enabled: mobypay_data?.show_visa_logo,
          src: mobypay_data?.plugin_url + '/assets/images/visa.png',
          alt: 'Visa'
        },
        {
          enabled: mobypay_data?.show_mastercard_logo,
          src: mobypay_data?.plugin_url + '/assets/images/mastercard.png',
          alt: 'Mastercard'
        },
        {
          enabled: mobypay_data?.show_online_banking_logo,
          src: mobypay_data?.plugin_url + '/assets/images/online_bank.png',
          alt: 'Online Banking'
        },
        {
          enabled: mobypay_data?.show_duitnow_logo,
          src: mobypay_data?.plugin_url + '/assets/images/duitnow.png',
          alt: 'DuitNow'
        },
        {
          enabled: mobypay_data?.show_grabpay_logo,
          src: mobypay_data?.plugin_url + '/assets/images/grab_pay.png',
          alt: 'GrabPay'
        },
        {
          enabled: mobypay_data?.show_paylater_logo,
          src: mobypay_data?.plugin_url + '/assets/images/pay_later.png',
          alt: 'Pay Later'
        }
      ];
      const showCashback = Boolean(mobypay_data?.show_cashback_logo);
      const enabledLogos = labelLogoConfig.filter((logo) => Boolean(logo.enabled));
      const labelLogoItems = enabledLogos.map((logo, index) =>
        el('img', {
          src: logo.src,
          alt: logo.alt,
          onError: function (ev) {
            ev.target.style.display = 'none';
          },
          ref: imp({
            height: '28px',
            width: 'auto',
            display: 'block',
            'margin-inline-end':
              showCashback && index === enabledLogos.length - 1 ? '8px' : '0'
          })
        })
      );

      // Cashback badge rebuilt as markup (mirrors cashback.png): a gold rounded
      // pill with the merchant percentage and a "Cashback" label.
      const cashbackPercentage = Number(mobypay_data?.cashback_percentage) || 10;
      if (showCashback) {
        labelLogoItems.push(
          el(
            'span',
            {
              ref: imp({
                display: 'inline-flex',
                'align-items': 'center',
                'justify-content': 'center',
                gap: '2px',
                'line-height': '1',
                height: '24px',
                padding: '0 9px',
                'border-radius': '12px',
                background: 'linear-gradient(180deg,#FCC419 0%,#F0A800 100%)',
                color: '#3a2c00',
                'box-shadow': '0 1px 2px rgba(0,0,0,0.2)'
              })
            },
            el(
              'span',
              { ref: imp({ 'font-size': '12px', 'font-weight': '600' }) },
              cashbackPercentage + '%'
            ),
            el(
              'span',
              {
                ref: imp({
                  'font-size': '11px',
                  'font-weight': '600',
                  'letter-spacing': '0.2px'
                })
              },
              'Cashback'
            )
          )
        );
      }

      const labelChildren = [
        'Moby',
        labelLogoItems.length
          ? el(
              'span',
              {
                ref: imp({
                  display: 'inline-flex',
                  'align-items': 'center',
                  'flex-wrap': 'wrap',
                  gap: '8px'
                })
              },
              labelLogoItems
            )
          : null
      ].filter(Boolean);

      // No expandable content is shown when the method is selected — the logos
      // and cashback badge live on the label itself. An empty component keeps
      // WooCommerce from spreading payment props onto the DOM.
      const Content = () => null;

      const Label = () =>
        el(
          'span',
          {
            ref: imp({
              'font-weight': '600',
              display: 'inline-flex',
              'align-items': 'center',
              'flex-wrap': 'wrap',
              'column-gap': '12px',
              'row-gap': '6px'
            })
          },
          labelChildren
        );

      const options = {
        name: 'moby-checkout',
        title: 'Moby',
        paymentMethodId: 'moby-checkout',
        ariaLabel: 'Moby',
        canMakePayment: () => true,
        supports: {
          features: ['products'],
        },

        content: el(Content),

        edit: el(
          'div',
          { className: 'moby-checkout-preview' },
          'Moby (Preview in Editor)'
        ),

        label: el(Label),
      };

      console.log('MOBYPAY Blocks V2 loaded');
      registerPaymentMethod(options);
    }
  })(window.wc?.wcBlocksRegistry, window.wp?.element);
});
