window.addEventListener('load', function (e) {
  (function (registry, element) {
    if (registry && element) {
      const el = element.createElement;
      const { registerPaymentMethod } = registry;

      const options = {
        name: 'moby-checkout',
        title: 'Moby Checkout Widget',
        paymentMethodId: 'moby-checkout',
        ariaLabel: 'Moby Checkout',
        canMakePayment: () => true,
        supports: {
          features: ['products'],
        },

        content: el(
          'div',
          { className: 'moby-checkout-description', style: {paddingLeft: '55px', fontSize: '15px'} },
          [
            el('p', {
              style: {margin: "4px 0"}
            }, 'Pay securely using Moby Checkout.'),
            el('img', {
              src: mobypay_data.plugin_url + '/assets/images/logo.png',
              alt: 'Pay with Moby Checkout',
              style: { maxHeight: '40px', width: 'auto'},
            }),
          ]
        ),

        edit: el(
          'div',
          { className: 'moby-checkout-preview' },
          'Moby Checkout (Preview in Editor)'
        ),

        label: el('span', {}, 'Moby Checkout'),
      };

      console.log('MOBYPAY Blocks V2 loaded');
      registerPaymentMethod(options);
    }
  })(window.wc?.wcBlocksRegistry, window.wp?.element);
});
