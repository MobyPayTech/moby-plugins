window.addEventListener('load', function (e) {
  (function (registry, element) {
    if (registry && element) {
      const el = element.createElement;
      const { registerPaymentMethod } = registry;
      const labelLogoConfig = [
        {
          enabled: mobypay_data?.show_visa_logo,
          src: mobypay_data?.plugin_url + '/assets/images/visa.svg',
          alt: 'Visa'
        },
        {
          enabled: mobypay_data?.show_mastercard_logo,
          src: mobypay_data?.plugin_url + '/assets/images/mastercard.svg',
          alt: 'Mastercard'
        },
        {
          enabled: mobypay_data?.show_maybank_logo,
          src: mobypay_data?.plugin_url + '/assets/images/maybank.png',
          alt: 'Maybank'
        },
        {
          enabled: mobypay_data?.show_fpx_logo,
          src: mobypay_data?.plugin_url + '/assets/images/fpx.svg',
          alt: 'FPX'
        }
      ];
      const labelLogoItems = labelLogoConfig
        .filter((logo) => Boolean(logo.enabled))
        .map((logo, index) =>
          el('img', {
            src: logo.src,
            alt: logo.alt,
            style: {
              height: '24px',
              width: 'auto',
              display: 'block',
              marginLeft: index === 0 ? '12px' : '0'
            }
          })
        );
      const cashbackBadge = el(
        'span',
        {
          style: {
            marginLeft: '8px',
            padding: '2px 8px',
            borderRadius: '999px',
            background: '#0f6ecd',
            color: '#ffffff',
            fontSize: '11px',
            fontWeight: '600',
            whiteSpace: 'nowrap'
          }
        },
        'Up to 10% cashback'
      );

      const labelChildren = [
        'Moby Checkout',
        labelLogoItems.length
          ? el(
              'span',
              {
                style: {
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '0'
                }
              },
              labelLogoItems
            )
          : null,
        cashbackBadge
      ].filter(Boolean);

      // Wrap markup in components (functions) so WooCommerce does NOT spread
      // payment props (billing, cartData, eventRegistration, ...) onto the DOM.
      // Plain, inline-styled markup that matches the classic-checkout
      // payment_fields() output so both checkout types look the same.
      const Content = () =>
        el(
          'div',
          {
            className: 'moby-checkout-description',
            style: {
              padding: '12px 16px',
              borderRadius: '8px',
              background: '#f6f7f7',
              border: '1px solid #e5e7eb',
              fontSize: '14px',
              lineHeight: '1.5',
              color: '#12304a'
            }
          },
          mobypay_data?.description || ''
        );

      const Label = () =>
        el(
          'span',
          { style: { fontWeight: '600', display: 'inline-flex', alignItems: 'center' } },
          labelChildren
        );

      const options = {
        name: 'moby-checkout',
        title: 'Moby Checkout Widget',
        paymentMethodId: 'moby-checkout',
        ariaLabel: 'Moby Checkout',
        canMakePayment: () => true,
        supports: {
          features: ['products'],
        },

        content: el(Content),

        edit: el(
          'div',
          { className: 'moby-checkout-preview' },
          'Moby Checkout (Preview in Editor)'
        ),

        label: el(Label),
      };

      console.log('MOBYPAY Blocks V2 loaded');
      registerPaymentMethod(options);
    }
  })(window.wc?.wcBlocksRegistry, window.wp?.element);
});
