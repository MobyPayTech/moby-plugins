console.log('MOBYPAY Script V3 loaded');

window.addEventListener('load', function (e) {
  (function (registry, element) {
    if (registry && element) {
      const el = element.createElement;
      const { registerPaymentMethod } = registry;

      const options = {
        name: 'moby-checkout',
        title: 'Moby Checkout Widget',
        content: el('img', {
          src: mobypay_data.plugin_url + '/assets/images/logo.png',
          alt: 'Pay with Moby Checkout',
          style: {
            maxHeight: '80px',
            width: 'auto',
            marginLeft: '40px',
            marginTop: '-20px',
          },
        }),
        edit: el(
          () => {
            return 'Pay with Moby Checkout';
          },
          {},
          'Pay with Moby Checkout'
        ),
        canMakePayment: () => true,
        paymentMethodId: 'moby-checkout',
        label: el('div', { id: 'moby-checkout' }, 'Moby Checkout'),
        ariaLabel: 'Moby Checkout',
        supports: {
          features: ['products'],
        },
      };

      console.log('MOBYPAY Blocks V2 loaded');

      const payment = registerPaymentMethod(options);
    }
  })(window.wc?.wcBlocksRegistry, window.wp?.element);
});
