<?php

defined('ABSPATH') || exit;
use Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry;
use Automattic\WooCommerce\Blocks\Integrations\IntegrationInterface;

if (!defined('MAIN_PLUGIN_FILE')) {
	define('MAIN_PLUGIN_FILE', __FILE__);
}

add_filter('woocommerce_available_payment_gateways', 'is_available', 1);
add_action('wp_enqueue_scripts', 'register_scripts');
add_filter('plugin_action_links_' . MOBYPAY_PLUGIN_FILE, 'add_settings_link');



function is_available($gateway_list) {
	if (get_option('woocommerce_currency') != 'MYR') {
		unset($gateway_list['mobypay-checkout']);
	}
	return $gateway_list;
}

function add_settings_link($links) {
	$links[] = '<a href="' . admin_url('admin.php?page=wc-settings&tab=checkout&section=moby-checkout') . '">' . __('Settings') . '</a>';
	return $links;
}

function register_scripts() {
	wp_register_style('mobypay-checkout', plugins_url('../assets/css/mobypay-checkout.css', __FILE__));
	wp_enqueue_style('mobypay-checkout');
	wp_register_script('mobypay-checkout', plugins_url('../assets/js/mobypay-checkout.js', __FILE__));
	wp_enqueue_script('mobypay-checkout');

	wp_register_script('moby-checkout-block', plugins_url('../assets/blocks/block.js', __FILE__), array('wp-blocks'), '1.0.0', true);
	wp_localize_script('moby-checkout-block', 'mobypay_data', array(
		'plugin_url' => plugins_url('', dirname(__FILE__))
	));
	wp_enqueue_script('moby-checkout-block');
}

function init() {
	if (!class_exists('WooCommerce') || !class_exists('WC_Payment_Gateway')) {
		return;
	}

	$GLOBALS['MobypayCheckout'] = MobypayCheckout::instance();

	require_once plugin_dir_path(__FILE__) . 'mobypay-checkout-gateway.php';
	add_filter('woocommerce_payment_gateways', function ($gateways) {
		if (!class_exists('WC_Payment_Gateway'))
			return;
		$gateways[] = 'MobypayCheckoutGateway';
		return $gateways;
	});
}

function wc_mobypay_register_block() {
	if (!class_exists('Automattic\WooCommerce\Blocks\Package'))
		return;

	require_once plugin_dir_path(__FILE__) . 'MobypayCheckoutBlocks.php';

	add_action('woocommerce_blocks_payment_method_type_registration', function (PaymentMethodRegistry $payment_method_registry) {
		$payment_method_registry->register(new MobypayCheckoutBlocks);

		$blocks_json = MOBYPAY_PLUGIN_DIR . '/block.json';
		$args = array(
			'frontend_script' => true,
			'backend_style' => false,
			'frontend_style' => false,
		);

		$plugin_root = MOBYPAY_PLUGIN_DIR;
		$path = explode('/', MOBYPAY_PLUGIN_DIR);
		$path = array_slice($path, -3);
		$plugin_url = '//' . $_SERVER['HTTP_HOST'] . '/' . implode('/', $path);

		$script_helper_data = array('dependencies' => array('wp-blocks'), 'version' => '0.1');
		wp_register_script('mobypay-checkout-editor', $plugin_url . '/assets/blocks/block.js', $script_helper_data['dependencies'], $script_helper_data['version'], true);

		$script_helper_data = array('dependencies' => array('wp-blocks'), 'version' => '0.1');
		wp_register_script('mobypay-checkout', $plugin_url . '/assets/blocks/block.js', $script_helper_data['dependencies'], $script_helper_data['version'], true);

		$registry = register_block_type_from_metadata($blocks_json, $args);
	});
}


if (!class_exists('MobypayCheckout')) {
	/**
	 * The mobypay-checkout class.
	 */
	class MobypayCheckout {
		/**
		 * This class instance.
		 *
		 * @var mixed
		 */
		private static $instance;
		private static $version = '1.0.0';

		/**
		 * Cloning is forbidden.
		 */
		public function __clone() {
			wc_doing_it_wrong(__FUNCTION__, __('Cloning is forbidden.', 'mobypay-checkout'), $this->version);
		}

		/**
		 * Unserializing instances of this class is forbidden.
		 */
		public function __wakeup() {
			wc_doing_it_wrong(__FUNCTION__, __('Unserializing instances of this class is forbidden.', 'mobypay-checkout'), $this->version);
		}

		/**
		 * Gets the main instance.
		 *
		 * Ensures only one instance can be loaded.
		 *
		 * @return \MobypayCheckout
		 */
		public static function instance() {
			if (self::$instance === null) {
				self::$instance = new self();
			}

			return self::$instance;
		}
	}
}

add_action('plugins_loaded', 'init', 10);
add_action('woocommerce_blocks_loaded', 'wc_mobypay_register_block');


