<?php

use JetBrains\PhpStorm\NoReturn;

require_once plugin_dir_path(__FILE__) . 'payment.php';

/**
 * MobypayCheckoutGateway Class
 */
class MobypayCheckoutGateway extends WC_Payment_Gateway {

    public $title = '';
    public $description = '';
    public $enabled = '';
    public $testmode = false;
    public $api_key = '';
    public $merchant_id = '';
    public $merchant_name = '';
    public $icon = '';

    public function __construct() {
        $this->id = 'moby-checkout';
        $this->has_fields = true;
        $this->method_title = __('Moby Checkout', 'moby-payment-gateway');
        $this->method_description = __('Moby Checkout offers a seamless payment experience for both you and your customers. With a user-friendly interface and easy integration, you can start accepting payments quickly and efficiently.', 'mobypay-payment-gateway');

        $this->supports = array(
            'products',
            // 'refunds', DISABLE FOR NOW
        );

        $this->init_form_fields();
        $this->init_settings();

        $this->title = 'Moby Checkout';
        $this->description = 'Pay Conveniently and Securely';
        $this->enabled = $this->get_option('enabled');
        $this->testmode = 'test' === $this->get_option('mode');
        $this->api_key = $this->get_option('api_key');
        $this->merchant_id = $this->get_option('merchant_id');
        $this->merchant_name = $this->get_option('company_name');
        $this->icon = apply_filters('woocommerce_mobypay_icon', plugins_url('../assets/images/logo.png', __FILE__));

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_api_' . $this->id, array($this, 'mobypay_callback'));
        add_action('woocommerce_thankyou', array($this, 'mobypay_response'));
    }

    public function process_admin_options() {
        $merchant_id = trim($_POST['woocommerce_moby-checkout_merchant_id'] ?? '');
        $api_key = trim($_POST['woocommerce_moby-checkout_api_key'] ?? '');
        $error_msg = null;

        /* --------------------------- IF VALUE EMPTY --------------------------- */
        if ($merchant_id === '' || $api_key === '') {
            unset($_POST['woocommerce_moby-checkout_enabled']);
            $_POST['woocommerce_moby-checkout_merchant_id'] = $this->settings['merchant_id'];
            $_POST['woocommerce_moby-checkout_api_key'] = $this->settings['api_key'];
            $error_msg = 'Please provide your Mobypay credential to enable this extension.';
        } else {
            /* --------------------------- VERIFY TOKEN ONLY IF THERES CHANGES --------------------------- */
            if ($this->settings['merchant_id'] != $merchant_id || $this->settings['api_key'] != $api_key) {
                $live_token = null;
                $dev_token = null;
                $live_error = null;
                $dev_error = null;

                /* --------------------------- LIVE TOKEN --------------------------- */
                $options['test'] = false;
                $options['merchant_id'] = $merchant_id;
                $options['api_key'] = $api_key;
                $response = Payment::getToken($options);

                if (empty($response->token)) {
                    $live_error = $response->msg ?? $response->error ?? null;
                } else {
                    $live_token = $response->token;
                }

                /* --------------------------- DEV TOKEN --------------------------- */
                $options['test'] = true;
                $options['merchant_id'] = $merchant_id;
                $options['api_key'] = $api_key;
                $response = Payment::getToken($options);

                if (empty($response->token)) {
                    $dev_error = $response->msg ?? $response->error ?? null;
                } else {
                    $dev_token = $response->token;
                }

                /* --------------------------- IF NO TOKEN --------------------------- */
                if (!$live_token && !$dev_token) {
                    unset($_POST['woocommerce_moby-checkout_enabled']);
                    $error_msg = $live_error ?? $dev_error ?? 'Something went wrong';
                }
            }
        }

        /* --------------------------- PRODUCE WOOCOMMERCE ERROR --------------------------- */
        if ($error_msg) {
            add_action('admin_notices', function () use ($error_msg) {
                $message = '<div class="notice notice-error is-dismissible"><p>' . $error_msg . '</p></div>';
                $message .= '<script>(function() {';
                $message .= 'const s = document.createElement("STYLE");';
                $message .= 's.innerHTML = "#message { display:none; }";';
                $message .= 'document.head.appendChild(s);';
                $message .= '})();</script>';
                echo $message;
            }, 10);
        }

        parent::process_admin_options();

        return true;
    }

    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title' => __('Enable', 'mobypay-payment-gateway'),
                'type' => 'checkbox',
                'description' => '',
                'default' => 'no',
            ),
            'mode' => array(
                'title' => __('Environment', 'mobypay-payment-gateway'),
                'type' => 'select',
                'description' => __('Test mode allow you to test the plugin without processing money, make sure you set the plugin to live mode and click on "Save changes" for real customers to use it', 'mobypay-payment-gateway'),
                'default' => 'Test',
                'options' => array(
                    'live' => __('Production Mode', 'mobypay-payment-gateway'),
                    'test' => __('Sandbox Mode', 'mobypay-payment-gateway')
                )
            ),
            'merchant_id' => array(
                'title' => __('Merchant ID', 'mobypay-payment-gateway'),
                'type' => 'text',
                'description' => __('Please refer to your Mobypay account.', 'mobypay-payment-gateway'),
            ),
            'api_key' => array(
                'title' => __('API Key', 'mobypay-payment-gateway'),
                'type' => 'text',
                'description' => __('Please refer to your Mobypay account.', 'mobypay-payment-gateway'),
            ),
            'company_name' => array(
                'title' => __('Company Name', 'mobypay-payment-gateway'),
                'type' => 'text',
                'description' => __('Company Name.', 'mobypay-payment-gateway'),
            ),
        );
    }

    public function process_payment($order_id) {
        global $woocommerce;
        $pay_for_order = $_GET['pay_for_order'] ?? null;

        if (!$pay_for_order) {
            WC()->session->__unset('order_id');
        }

        $o = wc_get_order($order_id);

        if (!$o) {
            return [];
        }

        /* --------------------------- CURRENCY ONLY MYR --------------------------- */
        if ($o->get_currency() != 'MYR') {
            $this->setMessages('Currency must be in MYR', 'error');
            return [];
        }

        if (!$pay_for_order) {
            WC()->session->set('order_id', $order_id);
        }
        $order = $o->get_data();

        /* --------------------------- CONSTRUCT CART DATA --------------------------- */
        $order['cart']['items'] = [];
        $order['cart']['amount'] = $order['total'];
        $items = $o->get_items();
        foreach ($items as $k => $item) {
            $product = $item->get_product();
            $order['cart']['items'][] = [
                'product' => [
                    'id' => $product->get_id(),
                    'title' => $product->get_name(),
                    'price' => number_format($product->get_price(), 2),
                ],
                'amount' => $item->get_total(),
                'quantity' => $item->get_quantity()
            ];
        }

        /* --------------------------- RETURN URL --------------------------- */
        $return_url = $this->get_return_url($o);
        $return_url .= '&mobypay_order_id=' . $order_id;
        $return_url .= '&type=payment&';

        $callback_url = wc_get_endpoint_url('wc-api/moby-checkout', '', wc_get_page_permalink(''));
        $callback_url .= '?mobypay_order_id=' . $order_id;
        $callback_url .= '&type=payment';

        /* --------------------------- PREPARE PAYLOAD --------------------------- */
        $options['order'] = $order;
        $options['order']['order_id'] = $order_id;
        $options['test'] = $this->testmode;
        $options['merchant_id'] = $this->merchant_id;
        $options['api_key'] = $this->api_key;
        $options['return_url'] = $return_url;
        $options['callback_url'] = $callback_url;
        $options['store_name'] = $this->merchant_name;
        $payment = Payment::create($options);

        /* --------------------------- HANDLE ERROR --------------------------- */
        if (!empty($payment->error)) {
            $this->setMessages($payment->msg ?? $payment->error, 'error');
            return [];
        }
        if (empty($payment->payLink)) {
            $this->setMessages('Mobypay is experiencing an error at the moment.', 'error');
            return [];
        }

        /* --------------------------- DET REDIRECT IF PAY FROM ORDER PAGE --------------------------- */
        if ($pay_for_order) {
            header("location: {$payment->payLink}");
            return [];
        }

        return [
            'result' => 'success',
            'redirect' => $payment->payLink
        ];
    }

    public function process_refund($order_id, $amount = null, $reason = '') {
        $o = wc_get_order($order_id);
        $order = $o->get_data();

        if ($order['status'] == 'refunded') {
            new WP_Error('error', __('Order already refunded.', 'woocommerce'));
            return false;
        }
        if ($amount === '0.00') {
            new WP_Error('error', __('Amount cannot be empty.', 'woocommerce'));
            return false;
        }
        if (!$this->can_refund_order($o)) {
            new WP_Error('error', __('Order cannot be refunded.', 'woocommerce'));
            return false;
        }

        $callback_url = wc_get_endpoint_url('wc-api/moby-checkout', '', wc_get_page_permalink(''));
        $callback_url .= '?mobypay_order_id=' . $order_id;
        $callback_url .= '&type=refund';

        $options['amount'] = $amount;
        $options['order'] = $order;
        $options['test'] = $this->testmode;
        $options['merchant_id'] = $this->merchant_id;
        $options['api_key'] = $this->api_key;
        $options['callback_url'] = $callback_url;
        $options['store_name'] = $this->merchant_name;
        $refund = Payment::refund($options);

        if (!empty($refund->error) && !empty($refund->msg)) {
            $o->add_order_note(__('Mobypay : ' . $refund->msg, 'woocommerce'));
            new WP_Error('error', __($refund->msg, 'woocommerce'));
            return false;
        } else {
            $o->add_order_note(__('Mobypay : Refund request is being processed.', 'woocommerce'));
            return true;
        }
    }

    public function request() {
        // Capture raw request body
        $request_body = file_get_contents('php://input');

        // Parse JSON data if the content type is application/json
        $json_data = [];
        if (isset($_SERVER['CONTENT_TYPE']) && strpos($_SERVER['CONTENT_TYPE'], 'application/json') !== false) {
            $json_data = json_decode($request_body, true) ?? [];
        }

        // Merge all possible input sources
        return array_merge($_GET, $_POST, $json_data);
    }

    public function mobypay_callback() {
        $data = $this->request();
        $transaction_id = $data['transactionId'] ?? null;
        $status = $data['status'] ?? null;
        $type = $data['type'] ?? 'payment';
        $mobypay_order_id = $data['mobypay_order_id'] ?? null;

        if (!$status) {
            $this->response(['error' => 'Status is missing.', 'status' => 'failed']);
        }

        if (!$mobypay_order_id) {
            $this->response(['error' => 'Mobypay order id is missing.', 'status' => 'failed']);
        }

        if (!$transaction_id) {
            $this->response(['error' => 'Transaction id is missing.', 'status' => 'failed']);
        }

        $order = wc_get_order($mobypay_order_id);

        if (!$this->validate_hmac()) {
            $order->add_order_note(__("Mobypay : Signature invalid", 'woocommerce'));

            $this->response(['error' => 'HMAC mismatch', 'status' => 'failed']);
        }

        if ($type == 'payment') {
            if (!$order->has_status('processing') && !$order->has_status('completed')) {
                if ($status == 'success') {
                    $order->add_order_note(__("Mobypay payment success. Transaction ID : {$transaction_id}", 'woocommerce'));
                    $order->payment_complete($transaction_id);
                } elseif ($status == 'failed') {
                    $order->add_order_note(__("Mobypay payment failed. Transaction ID : {$transaction_id}", 'woocommerce'));
                } elseif ($status == 'cancelled') {
                    $order->add_order_note(__("Mobypay payment cancelled. Transaction ID : {$transaction_id}", 'woocommerce'));
                } elseif ($status == 'processing') {
                    $order->add_order_note(__("Mobypay payment is being processed", 'woocommerce'));
                }
            }
        } elseif ($type == 'refund') {
            if (!$order->has_status('refunded')) {
                if ($status == 'success') {
                    $order->update_status('refunded', __("Mobypay refund success. Transaction ID : {$transaction_id}", 'woocommerce'));
                }
            }
        }

        $this->response(['message' => 'Callback received successfully', 'status' => 'success']);
    }

    public function response($data): void {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data);
        exit;
    }

    public function mobypay_response($order_id) {
        $transaction_id = $_GET['transactionId'] ?? $_GET['?transactionId'] ?? '';
        $status = $_GET['status'] ?? $_GET['?status'] ?? null;
        $type = $_GET['type'] ?? 'payment';
        $mobypay_order_id = $_GET['mobypay_order_id'] ?? null;

        if (!$mobypay_order_id) {
            return '';
        }

        $order = wc_get_order($mobypay_order_id);
        $img_url = plugins_url('../assets/images/logo.png', __FILE__);

        /* --------------------------- SUCCESS MSG --------------------------- */
        $success = <<<SCRIPT
        <script>
            const msg = document.querySelector('.woocommerce-notice');
            if (msg) {
                msg.innerHTML = 'Thank you. Your payment has been successful.';
                msg.classList.add('mobypay-success-message');
            }
        </script>
        SCRIPT;

        /* --------------------------- ERROR MSG --------------------------- */
        $error = <<<SCRIPT
        <script>
            let msg = document.querySelector('.woocommerce-notice');
            if(!msg){
                msg = document.querySelector('.wc-block-order-confirmation-status');
            }
            console.log('msg', msg);
            if (msg) {
                msg.innerHTML = 'Sorry. Your payment has been unsuccessful.';
                msg.classList.add('mobypay-error-message');
            }
        </script>
        SCRIPT;

        /* --------------------------- SET IMG VARIABLE TO JS --------------------------- */
        $logo = '<script>window.IMG_URL = "' . $img_url . '"</script>';
        $logo .= <<<SCRIPT
        <script>
            const method = document.querySelector('.woocommerce-order-overview__payment-method');
            if (method) {
                method.innerHTML = 'Payment Method';
                method.innerHTML += '<img src="'+IMG_URL+'" alt="Moby Checkout" class="moby-result-logo">';
                method.innerHTML += '<strong>Moby Checkout</strong>';
            }
        </script>
        SCRIPT;

        echo $logo;

        if (!$order) {
            return '';
        }
        /* --------------------------- VALIDATE HMAC SIGNATURE --------------------------- */
        if (!$this->validate_hmac()) {
            echo $error;
            return $order->add_order_note(__("Mobypay : Signature invalid", 'woocommerce'));
        }

        /* --------------------------- UPDATE ORDER STATUS --------------------------- */
        if ($type == 'payment') {
            if (!$order->has_status('processing') && !$order->has_status('completed')) {
                if ($status == 'success') {
                    echo $success;
                    $order->add_order_note(__("Mobypay payment success. Transaction ID : {$transaction_id}", 'woocommerce'));
                    $order->payment_complete($transaction_id);
                } elseif ($status == 'failed') {
                    echo $error;
                    $order->add_order_note(__("Mobypay payment failed. Transaction ID : {$transaction_id}", 'woocommerce'));
                } elseif ($status == 'cancelled') {
                    echo $error;
                    $order->add_order_note(__("Mobypay payment cancelled. Transaction ID : {$transaction_id}", 'woocommerce'));
                } elseif ($status == 'processing') {
                    echo $error;
                    $order->add_order_note(__("Mobypay payment is being processed", 'woocommerce'));
                } else {
                    echo $error;
                }
            }
        } elseif ($type == 'refund') {
            if (!$order->has_status('refunded')) {
                if ($status == 'success') {
                    echo $success;
                    $order->update_status('refunded', __("Mobypay refund success. Transaction ID : {$transaction_id}", 'woocommerce'));
                }
            }
        }
        return '';
    }

    public function validate_hmac() {
        $params = $this->request();
        $signature = $params['signature'] ?? '';
        $referenceNo = $params['referenceNo'] ?? '';
        unset($params['signature']);
        unset($params['key']);
        unset($params['mobypay_order_id']);
        unset($params['type']);
        unset($params['?referenceNo']);
        $params['referenceNo'] = $referenceNo;

        if (
            !isset($params['referenceNo']) ||
            !isset($params['transactionId']) ||
            !isset($params['amount']) ||
            !isset($params['payMethod']) ||
            !isset($params['status'])
        ) {
            return false;
        }

        $redirectData = [
            'referenceNo' => $params['referenceNo'],
            'transactionId' => $params['transactionId'],
            'amount' => $params['amount'],
            'payMethod' => $params['payMethod'],
            'status' => $params['status'],
            'time' => $params['time'],
        ];
        ksort($redirectData);
        $stringSign = implode('', $redirectData);
        $api_key = $this->get_option('api_key');
        $generated_signature = hash_hmac('sha256', $stringSign, $api_key);
        return hash_equals($signature, $generated_signature);
    }

    private function setMessages($message = '', $class = '') {
        global $woocommerce;

        if (function_exists('wc_add_notice')) {
            wc_add_notice($message, $class);
        } else {
            if ('success' == $class) {
                $woocommerce->add_message($message);
            } else {
                $woocommerce->add_error($message);
            }

            $woocommerce->set_messages();
        }
    }
}
