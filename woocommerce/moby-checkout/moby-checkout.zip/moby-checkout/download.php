<?php

$file = $_GET['file'] ?? null;

if (!$file) die;

$file = __DIR__.'/'.$file;
if (!file_exists($file)) die;

$file = file_get_contents($file);

header('Content-Type: text/plain');
echo $file;