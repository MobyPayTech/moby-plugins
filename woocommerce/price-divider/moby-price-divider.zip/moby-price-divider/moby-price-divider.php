<?php
/*
Plugin Name: Moby Price Divider
Description: Displays installment options (e.g., 3 months or 6 months) below the product price on WooCommerce product pages.
Version: 1.0
Author: MobyPay
Author URI: https://moby.my/
License: GPLv2 or later
Text Domain: moby-price-divider
*/


class MobyPriceDivider {
    public function __construct() {
        add_action('admin_menu', [$this, 'adminPage']);
        add_action('admin_init', [$this, 'settings']);
        register_activation_hook(__FILE__, [$this, 'set_default_options']);
        add_filter('woocommerce_get_price_html', [$this, 'customize_product_price_display'], 10, 2);
    }
    function customize_product_price_display($price, $product) {
        ob_start();
        $this->createPriceDividerHTML();
        $price_divider_html = ob_get_clean(); // Capture the HTML output

        // Check if on the product loop (shop or category pages)
        if (is_product_category() || is_shop() || is_product_tag()) {
            // Return the price with the price divider HTML
            return $price . ' ' . $price_divider_html;
        }

        // Check if on a single product page
        if (is_product()) {

            // Check if We are in single page > related product section
            if (did_action('woocommerce_after_single_product_summary') > 0) {
                return $price . ' ' . $price_divider_html;
            }

            // otherwise
            ob_start();
            $this->createPriceDividerHTMLForProductDetaisPage();
            $price_divider_html_with_learn_more_button = ob_get_clean(); // Capture the HTML output

            // Return the price with the price divider HTML
            return $price . ' ' . $price_divider_html_with_learn_more_button;
        }

        return $price;
    }

    public function createPriceDividerHTMLForProductDetaisPage() {
        global $product;
        $mobyLogo = "https://mobypublicasset.s3.ap-southeast-1.amazonaws.com/Checkout+Images/moby-logo.png";
        $mobyIslamicLogo = "https://mobypublicasset.s3.ap-southeast-1.amazonaws.com/Checkout+Images/moby-islamic-logo.png";

        $productPrice = $product->get_sale_price() !== '' ? $product->get_sale_price() : $product->get_regular_price();

        // Check if the product object is available and has a regular price
        if ($product && $productPrice >= get_option('mpd_minimun_price') && get_option('mpd_is_active') === '1') {

            $installment_count = get_option('mpd_installment_count');
            $platform = get_option('mpd_platform');

            // Calculate installment amounts
            $installment_amount = number_format($productPrice / $installment_count, 2, '.', '');

            // Display the installment options after the price
            ?>


            <p style="font-size: 14px;margin-bottom: 1.5em;">Or <?php echo $installment_count ?> Payment of
                RM<?php echo $installment_amount ?>
                MYR with
                <img src="<?php echo $platform === 'moby' ? $mobyLogo : $mobyIslamicLogo; ?>" alt="Moby logo"
                    style="width: 45px; vertical-align: middle;">
                <button onclick="showMobyPriceDividerModal()" class="moby-learn-more-modal-button" style="display: block;
                background: transparent;
                border: none;
                text-decoration: underline;
                padding: 0;
                color: gray;cursor: pointer;" data-platform="<?php echo $platform ?>">Learn More</button>
            </p>

            <!-- MODAL -->
            <script>
                function showMobyPriceDividerModal() {
                    const mobyBanner = "https://mobypublicasset.s3.ap-southeast-1.amazonaws.com/Checkout+Images/moby-checkout.png";
                    const mobyIslamicBanner = "https://mobypublicasset.s3.ap-southeast-1.amazonaws.com/Checkout+Images/moby-islamic-checkout.png";

                    // Pass the platform value from a data attribute
                    const platform = this.dataset?.platform;

                    const modal = document.createElement('div');
                    modal.style.position = 'fixed';
                    modal.style.top = '0';
                    modal.style.left = '0';
                    modal.style.width = '100%';
                    modal.style.height = '100%';
                    modal.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
                    modal.style.zIndex = '1000';
                    modal.style.display = 'flex';
                    modal.style.alignItems = 'center';
                    modal.style.justifyContent = 'center';
                    modal.innerHTML = `
                                    <div style="background: white; padding: 2em; border-radius: 8px;
                                        max-width: 60vw;text-align: center;position:relative;">
                                        <button class="moby-learn-more-modal-close-btn" style="padding: 0.5em 1em;background:     transparent;color: gray;border: none;border-radius: 5px;cursor: pointer;position: absolute;right: 20px;top: 20px;">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-x">
                                                    <path d="M18 6 6 18"/>
                                                <path d="m6 6 12 12"/>
                                            </svg>
                                                                                                                                                                </button>
                                        <img src="${platform === 'moby' ? mobyBanner : mobyIslamicBanner}" alt="Moby Checkout banner" style="max-width: 100%;max-height: 70vh;">
                                    </div>`;
                    document.body.appendChild(modal);

                    // Add event listener for closing the modal
                    modal.querySelector('.moby-learn-more-modal-close-btn').addEventListener('click', () => {
                        document.body.removeChild(modal);
                    });
                };
            </script>

        <?php }
    }
    public function createPriceDividerHTML() {
        global $product;
        $mobyLogo = "https://mobypublicasset.s3.ap-southeast-1.amazonaws.com/Checkout+Images/moby-logo.png";
        $mobyIslamicLogo = "https://mobypublicasset.s3.ap-southeast-1.amazonaws.com/Checkout+Images/moby-islamic-logo.png";

        $productPrice = $product->get_sale_price() !== '' ? $product->get_sale_price() : $product->get_regular_price();

        // Check if the product object is available and has a regular price
        if ($product && $productPrice >= get_option('mpd_minimun_price') && get_option('mpd_is_active') === '1') {

            $installment_count = get_option('mpd_installment_count');
            $platform = get_option('mpd_platform');

            // Calculate installment amounts
            $installment_amount = number_format($productPrice / $installment_count, 2, '.', '');

            // Display the installment options after the price

            ?>


            <p style="font-size: 14px;">Or <?php echo $installment_count ?> Payment of RM<?php echo $installment_amount ?>
                MYR with
                <img src="<?php echo $platform === 'moby' ? $mobyLogo : $mobyIslamicLogo; ?>" alt="Moby Islamic logo"
                    style="width: 45px; vertical-align: middle;">
            </p>


        <?php }
    }

    // Or 2 Payment of RM12.00 MYR with moby logo

    public function settings() {
        add_settings_section('mpd_first_section', null, null, 'moby-price-divider');

        // Register Minimum price to show the price divider option
        add_settings_field('mpd_minimun_price', 'Minimum Price To Show Price Divider', [$this, 'minimumPriceHTML'], 'moby-price-divider', 'mpd_first_section');
        register_setting('mobypricedivider', 'mpd_minimun_price', [
            'sanitize_callback' => 'sanitize_text_field',
            'default' => 10
        ]);

        // Register Installment count option
        add_settings_field('mpd_installment_count', 'Installment Count', [$this, 'installmentCountHTML'], 'moby-price-divider', 'mpd_first_section');
        register_setting('mobypricedivider', 'mpd_installment_count', [
            'sanitize_callback' => 'sanitize_text_field',
            'default' => 2
        ]);

        // Register Platform option
        add_settings_field('mpd_platform', 'Platform', [$this, 'platformHTML'], 'moby-price-divider', 'mpd_first_section');
        register_setting('mobypricedivider', 'mpd_platform', [
            'sanitize_callback' => 'sanitize_text_field',
            'default' => 'moby'
        ]);

        // Register Activate/Deactivate button
        add_settings_field('mpd_is_active', 'Enable Plugin', [$this, 'isActiveHTML'], 'moby-price-divider', 'mpd_first_section');
        register_setting('mobypricedivider', 'mpd_is_active', [
            'sanitize_callback' => 'sanitize_text_field',
            'default' => 1
        ]);


    }

    public function minimumPriceHTML() {
        $option = get_option('mpd_minimun_price'); ?>
        <input type="number" id="mpd_minimun_price" name="mpd_minimun_price" value="<?php echo esc_attr($option) ?>" min="1" />
    <?php }

    public function installmentCountHTML() {
        $getSelectedInstallment = get_option('mpd_installment_count'); ?>
        <select name="mpd_installment_count" id="mpd_installment_count" style="width: 170px;">
            <option value="2" <?php selected($getSelectedInstallment, 2) ?>>2</option>
            <option value="3" <?php selected($getSelectedInstallment, 3) ?>>3</option>
            <option value="6" <?php selected($getSelectedInstallment, 6) ?>>6</option>
        </select>
    <?php }

    public function platformHTML() {
        $getSelectedPlatform = get_option('mpd_platform'); ?>
        <select name="mpd_platform" id="mpd_platform" style="width: 170px;">
            <option value="moby" <?php selected($getSelectedPlatform, 'moby') ?>>Moby</option>
            <option value="mobyislamic" <?php selected($getSelectedPlatform, 'mobyislamic') ?>>Moby Islamic</option>

        </select>
    <?php }

    public function isActiveHTML() {
        $getSelectedIsActive = get_option('mpd_is_active'); ?>
        <input type="checkbox" id="mpd_is_active" name="mpd_is_active" value="1" <?php checked($getSelectedIsActive, 1) ?> />
    <?php }

    public function adminPage() {
        add_options_page('Moby Price Divider', 'Price Divider', 'manage_options', 'moby-price-divider', [$this, 'ourHTML']);
    }

    public function set_default_options() {
        // Default settings
        $default_options = [
            'mpd_minimun_price' => 10,
            'mpd_installment_count' => 2,
            'mpd_platform' => 'moby',
            'mpd_is_active' => 1
        ];

        // Save default options if they are not already set
        foreach ($default_options as $key => $value) {
            if (get_option($key) === false) {
                update_option($key, $value);
            }
        }
    }

    public function ourHTML() { ?>
        <div class="wrap">
            <div>
                <img src="<?php echo plugin_dir_url(__FILE__) . '/moby_checkout.png' ?>" alt="">
                <!-- <h1>Moby Price Divider Settings</h1> -->
                <form action="options.php" method="POST">
                    <?php
                    settings_fields('mobypricedivider');
                    do_settings_sections('moby-price-divider');
                    submit_button();
                    ?>
                </form>
            </div>
        </div>
    <?php }
}


new MobyPriceDivider();