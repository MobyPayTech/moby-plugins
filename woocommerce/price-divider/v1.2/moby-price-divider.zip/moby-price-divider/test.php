<?php
 function createPriceDividerHTML() {
        global $product;
        $mobyLogo = "https://mobypublicasset.s3.ap-southeast-1.amazonaws.com/Checkout+Images/moby-logo.png";
        $mobyIslamicLogo = "https://mobypublicasset.s3.ap-southeast-1.amazonaws.com/Checkout+Images/moby-islamic-logo.png";

       if ( $product instanceof WC_Product ) {
        $productPrice = $product->get_sale_price() !== '' 
        ? $product->get_sale_price() 
        : $product->get_regular_price();
        } else {
            $productPrice = 0; // fallback if product is null
        }


        // Check if the product object is available and has a regular price
        if ($product && $productPrice >= get_option('mpd_minimun_price') && get_option('mpd_is_active') === '1') {

            $installment_count = get_option('mpd_installment_count');
            $platform = get_option('mpd_platform');

            // Calculate installment amounts
            $installment_amount = number_format($productPrice / $installment_count, 2, '.', '');

            // Display the installment options after the price

            ?>


            <p style="font-size: 14px;">Or <?php echo $installment_count ?> Payment of RM<?php echo $installment_amount ?>
                MYR with
                <img src="<?php echo $platform === 'moby' ? $mobyLogo : $mobyIslamicLogo; ?>" alt="Moby Islamic logo"
                    style="width: 45px; vertical-align: middle;">
            </p>


        <?php }
    }