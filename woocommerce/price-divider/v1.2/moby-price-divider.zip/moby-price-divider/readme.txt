=== Moby Price Divider ===
Contributors: [Your Name or Username]
Tags: WooCommerce, installments, price divider, ecommerce
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Displays installment options (e.g., 3 months or 6 months) below the product price on WooCommerce product pages.

== Description ==

Moby Price Divider is a WooCommerce plugin that displays installment options beneath the product price on product pages. This can help customers easily understand payment options, improving their shopping experience.

**Features:**
* Flexible installment options (2, 3, or 6 months).
* Compatible with Moby and Moby Islamic platforms.
* Minimum price threshold for displaying the installment option.
* Simple activation/deactivation through the WordPress settings page.

== Installation ==

1. Upload the plugin ZIP file via **Plugins > Add New > Upload Plugin**.
2. Activate the plugin through the **Plugins** menu in WordPress.
3. Go to **Settings > Price Divider** to configure the options.

== Frequently Asked Questions ==

= What are the minimum requirements to use this plugin? =
You need WooCommerce installed and active, PHP 7.4 or higher, and WordPress 5.0 or later.

= How can I change the installment count? =
Go to **Settings > Price Divider** and select the desired installment count from the dropdown menu.

= How do I activate or deactivate the plugin? =
You can toggle the "Enable Plugin" checkbox in the plugin's settings page under **Settings > Price Divider**.

== Screenshots ==

1. **Installment Option Example**  
   Shows how the installment option appears below the product price on WooCommerce product pages.

2. **Admin Settings**  
   Configure installment options, minimum price, and platform preferences.

== Changelog ==

= 1.0 =
* Initial release.
* Displays installment options based on admin-defined settings.

== Upgrade Notice ==

= 1.0 =
Initial release. Ensure WooCommerce is active before activating the plugin.

== License ==
This plugin is released under the GPLv2 or later license. You are free to use, modify, and distribute it as per the license terms.
