<?php
declare(strict_types=1);

namespace Moby\Checkout\Test\Unit\Model\Service;

use Moby\Checkout\Model\Service\SignatureValidator;
use PHPUnit\Framework\TestCase;

class SignatureValidatorTest extends TestCase
{
    public function testValidSignature(): void
    {
        $validator = new SignatureValidator();
        $apiKey = 'secret';

        $payload = [
            'referenceNo' => '100000001',
            'transactionId' => 'TXN123',
            'amount' => '100.00',
            'payMethod' => 'fpx',
            'status' => 'success',
            'type' => 'callback',
            'signature' => '',
        ];

        $toSign = $payload;
        unset($toSign['signature'], $toSign['type']);
        ksort($toSign);
        $concatenated = implode('', array_values($toSign));
        $payload['signature'] = hash_hmac('sha256', $concatenated, $apiKey);

        self::assertTrue($validator->isValid($payload, $apiKey));
    }

    public function testInvalidSignatureReturnsFalse(): void
    {
        $validator = new SignatureValidator();
        $payload = [
            'referenceNo' => '100000001',
            'transactionId' => 'TXN123',
            'amount' => '100.00',
            'payMethod' => 'fpx',
            'status' => 'success',
            'signature' => 'invalid-signature',
        ];

        self::assertFalse($validator->isValid($payload, 'secret'));
    }

    public function testMissingRequiredFieldsReturnsFalse(): void
    {
        $validator = new SignatureValidator();
        $payload = [
            'referenceNo' => '100000001',
            'signature' => 'abc',
        ];

        self::assertFalse($validator->isValid($payload, 'secret'));
    }
}
