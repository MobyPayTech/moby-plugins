<?php
declare(strict_types=1);

namespace Moby\Checkout\Test\Unit\Model\Service;

use Moby\Checkout\Model\Service\StatusMapper;
use PHPUnit\Framework\TestCase;

class StatusMapperTest extends TestCase
{
    public function testSuccessStatusMap(): void
    {
        $mapper = new StatusMapper();
        $mapped = $mapper->map('success');

        self::assertSame('success', $mapped['status']);
        self::assertTrue($mapped['should_mark_paid']);
        self::assertSame('Mobypay: Payment successful.', $mapped['comment']);
    }

    public function testFailedStatusMap(): void
    {
        $mapper = new StatusMapper();
        $mapped = $mapper->map('failed');

        self::assertSame('failed', $mapped['status']);
        self::assertFalse($mapped['should_mark_paid']);
        self::assertSame('Mobypay: Payment failed.', $mapped['comment']);
    }

    public function testUnknownStatusMap(): void
    {
        $mapper = new StatusMapper();
        $mapped = $mapper->map('unexpected-status');

        self::assertSame('unexpected-status', $mapped['status']);
        self::assertFalse($mapped['should_mark_paid']);
        self::assertSame('Mobypay: Payment returned unknown status.', $mapped['comment']);
    }
}
