<?php
declare(strict_types=1);

namespace Moby\Checkout\Logger;

use Magento\Framework\Logger\Handler\Base;
use Monolog\Logger;

class Handler extends Base
{
    protected $fileName = '/var/log/moby_checkout.log';

    protected $loggerType = Logger::INFO;
}
