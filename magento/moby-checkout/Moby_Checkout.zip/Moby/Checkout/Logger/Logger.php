<?php
declare(strict_types=1);

namespace Moby\Checkout\Logger;

use Monolog\Logger as MonologLogger;

class Logger extends MonologLogger
{
}
