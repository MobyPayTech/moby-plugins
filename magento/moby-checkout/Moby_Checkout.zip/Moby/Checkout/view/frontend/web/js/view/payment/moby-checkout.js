define([
    'uiComponent',
    'Magento_Checkout/js/model/payment/renderer-list'
], function (Component, rendererList) {
    'use strict';

    rendererList.push({
        type: 'moby_checkout',
        component: 'Moby_Checkout/js/view/payment/method-renderer/moby-checkout-method'
    });

    return Component.extend({});
});
