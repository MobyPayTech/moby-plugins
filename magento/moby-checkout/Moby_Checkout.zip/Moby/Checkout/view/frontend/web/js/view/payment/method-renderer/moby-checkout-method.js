define([
    'Magento_Checkout/js/view/payment/default',
    'mage/url',
    'Magento_Checkout/js/action/redirect-on-success',
    'require'
], function (Component, urlBuilder, redirectOnSuccessAction, require) {
    'use strict';

    return Component.extend({
        defaults: {
            template: 'Moby_Checkout/payment/moby-checkout',
            redirectAfterPlaceOrder: true
        },

        getCode: function () {
            return 'moby_checkout';
        },

        getDescription: function () {
            var config = window.checkoutConfig.payment.moby_checkout || {};
            return config.description || '';
        },

        getInfoDescription: function () {
            var description = this.getDescription();

            return description || 'Pay securely and earn up to 10% cashback on this order.';
        },

        getLogos: function () {
            var config = window.checkoutConfig.payment.moby_checkout || {};
            var logos = [];

            if (config.showVisaLogo) {
                logos.push({
                    src: require.toUrl('Moby_Checkout/images/payment/visa.svg'),
                    alt: 'Visa'
                });
            }

            if (config.showMastercardLogo) {
                logos.push({
                    src: require.toUrl('Moby_Checkout/images/payment/mastercard.svg'),
                    alt: 'Mastercard'
                });
            }

            if (config.showMaybankLogo) {
                logos.push({
                    src: require.toUrl('Moby_Checkout/images/payment/maybank.png'),
                    alt: 'Maybank'
                });
            }

            if (config.showFpxLogo) {
                logos.push({
                    src: require.toUrl('Moby_Checkout/images/payment/fpx.svg'),
                    alt: 'FPX'
                });
            }

            return logos;
        },

        getMobyLogoSrc: function () {
            return require.toUrl('Moby_Checkout/images/payment/moby-logo.png');
        },

        afterPlaceOrder: function () {
            redirectOnSuccessAction.redirectUrl = urlBuilder.build('moby/checkout_redirect/index');
        }
    });
});
