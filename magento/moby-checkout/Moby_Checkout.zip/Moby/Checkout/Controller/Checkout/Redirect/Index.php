<?php
declare(strict_types=1);

namespace Moby\Checkout\Controller\Checkout\Redirect;

use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\Controller\Result\Redirect as ResultRedirect;
use Magento\Sales\Api\OrderRepositoryInterface;
use Moby\Checkout\Logger\Logger;
use Moby\Checkout\Model\Config;
use Moby\Checkout\Model\Service\CheckoutService;

class Index extends Action implements HttpGetActionInterface
{
    private CheckoutSession $checkoutSession;

    private CheckoutService $checkoutService;

    private OrderRepositoryInterface $orderRepository;

    private Logger $logger;

    private Config $config;

    public function __construct(
        Context $context,
        CheckoutSession $checkoutSession,
        CheckoutService $checkoutService,
        OrderRepositoryInterface $orderRepository,
        Logger $logger,
        Config $config
    ) {
        parent::__construct($context);
        $this->checkoutSession = $checkoutSession;
        $this->checkoutService = $checkoutService;
        $this->orderRepository = $orderRepository;
        $this->logger = $logger;
        $this->config = $config;
    }

    public function execute(): ResultRedirect
    {
        /** @var ResultRedirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $this->logger->info('Mobypay: Redirect controller execute triggered.');

        $order = $this->checkoutSession->getLastRealOrder();
        if (!$order->getEntityId()) {
            $this->logger->warning('Mobypay redirect reached without a last real order in checkout session.');
            return $resultRedirect->setPath('checkout/cart');
        }

        $selectedMethod = (string)($order->getPayment()?->getMethod() ?? '');
        $this->logger->info('Mobypay redirect guard check', [
            'increment_id' => (string)$order->getIncrementId(),
            'selected_method' => $selectedMethod,
            'expected_method' => Config::METHOD_CODE,
        ]);

        if ($selectedMethod !== Config::METHOD_CODE) {
            $this->logger->warning('Mobypay redirect skipped because payment method does not match.', [
                'increment_id' => (string)$order->getIncrementId(),
                'selected_method' => $selectedMethod,
            ]);
            return $resultRedirect->setPath('checkout/onepage/success');
        }

        try {
            $response = $this->checkoutService->createHostedCheckout($order);
            $payLink = $response['payLink'];
            $this->logger->info('Mobypay hosted checkout link created', [
                'increment_id' => (string)$order->getIncrementId(),
                'pay_link' => (string)$payLink,
            ]);

            $payment = $order->getPayment();
            if ($payment !== null) {
                $payment->setAdditionalInformation('moby_reference_no', (string)$order->getIncrementId());
                $payment->setAdditionalInformation('moby_pay_link', (string)$payLink);
                $payment->setAdditionalInformation('moby_checkout_payload', $response['payload']);
            }
            $order->addCommentToStatusHistory('Mobypay: Hosted checkout link created.');
            $this->orderRepository->save($order);

            return $resultRedirect->setUrl((string)$payLink);
        } catch (\Throwable $exception) {
            $this->logger->error('Mobypay checkout initialization failed', [
                'order_id' => $order->getIncrementId(),
                'error' => $exception->getMessage(),
            ]);
            $this->messageManager->addErrorMessage(__('Unable to start Moby Checkout right now. Please choose another payment method or try again.'));
            $this->checkoutSession->restoreQuote();
            return $resultRedirect->setPath('checkout/cart');
        }
    }
}
