<?php
declare(strict_types=1);

namespace Moby\Checkout\Controller\Checkout\Callback;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Controller\Result\Json as JsonResult;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\OrderFactory;
use Moby\Checkout\Logger\Logger;
use Moby\Checkout\Model\Config;
use Moby\Checkout\Model\Service\OrderStatusProcessor;
use Moby\Checkout\Model\Service\RequestDataExtractor;
use Moby\Checkout\Model\Service\SignatureValidator;

class Index extends Action implements CsrfAwareActionInterface, HttpGetActionInterface, HttpPostActionInterface
{
    private RequestDataExtractor $requestDataExtractor;

    private SignatureValidator $signatureValidator;

    private OrderFactory $orderFactory;

    private OrderStatusProcessor $orderStatusProcessor;

    private JsonFactory $jsonFactory;

    private Logger $logger;

    private Config $config;

    private OrderRepositoryInterface $orderRepository;

    public function __construct(
        Context $context,
        RequestDataExtractor $requestDataExtractor,
        SignatureValidator $signatureValidator,
        OrderFactory $orderFactory,
        OrderStatusProcessor $orderStatusProcessor,
        JsonFactory $jsonFactory,
        Logger $logger,
        Config $config,
        OrderRepositoryInterface $orderRepository
    ) {
        parent::__construct($context);
        $this->requestDataExtractor = $requestDataExtractor;
        $this->signatureValidator = $signatureValidator;
        $this->orderFactory = $orderFactory;
        $this->orderStatusProcessor = $orderStatusProcessor;
        $this->jsonFactory = $jsonFactory;
        $this->logger = $logger;
        $this->config = $config;
        $this->orderRepository = $orderRepository;
    }

    public function execute(): JsonResult
    {
        $result = $this->jsonFactory->create();
        $payload = $this->requestDataExtractor->extract($this->getRequest());

        $referenceNo = trim((string)($payload['referenceNo'] ?? ''));
        $incrementId = $this->resolveIncrementId($referenceNo);
        if ($incrementId === '') {
            $this->getResponse()->setHttpResponseCode(400);
            return $result->setData(['success' => false, 'message' => 'Missing referenceNo']);
        }

        $order = $this->orderFactory->create()->loadByIncrementId($incrementId);
        if (!$order->getEntityId()) {
            $this->getResponse()->setHttpResponseCode(404);
            return $result->setData(['success' => false, 'message' => 'Order not found']);
        }

        $apiKey = $this->config->getApiKey((int)$order->getStoreId());
        if (!$this->signatureValidator->isValid($payload, $apiKey)) {
            $order->addCommentToStatusHistory('Mobypay: Invalid signature on callback payload.');
            $this->orderRepository->save($order);
            $this->logger->warning('Mobypay callback signature validation failed', [
                'reference_no' => $referenceNo,
                'increment_id' => $incrementId,
                'payload' => $payload,
            ]);
            $this->getResponse()->setHttpResponseCode(400);
            return $result->setData(['success' => false, 'message' => 'Invalid signature']);
        }

        try {
            $this->orderStatusProcessor->process($order, $payload, true);
            $this->logger->info('Mobypay callback processed successfully', [
                'reference_no' => $referenceNo,
                'increment_id' => $incrementId,
                'status' => (string)($payload['status'] ?? ''),
                'transaction_id' => (string)($payload['transactionId'] ?? ''),
            ]);
        } catch (\Throwable $exception) {
            $this->logger->error('Mobypay callback processing failed', [
                'reference_no' => $referenceNo,
                'increment_id' => $incrementId,
                'error' => $exception->getMessage(),
            ]);
            $this->getResponse()->setHttpResponseCode(500);
            return $result->setData(['success' => false, 'message' => 'Unable to process callback']);
        }

        return $result->setData(['success' => true, 'message' => 'Callback processed']);
    }

    public function createCsrfValidationException(RequestInterface $request): ?InvalidRequestException
    {
        return null;
    }

    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
    }

    private function resolveIncrementId(string $referenceNo): string
    {
        if ($referenceNo === '') {
            return '';
        }

        if (preg_match('/^MAGE-([0-9]+)-[0-9]+$/', $referenceNo, $matches) === 1) {
            return (string)$matches[1];
        }

        return $referenceNo;
    }
}
