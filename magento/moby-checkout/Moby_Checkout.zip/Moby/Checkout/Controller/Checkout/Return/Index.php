<?php
declare(strict_types=1);

namespace Moby\Checkout\Controller\Checkout\Return;

use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Controller\Result\Redirect as ResultRedirect;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\OrderFactory;
use Moby\Checkout\Logger\Logger;
use Moby\Checkout\Model\Config;
use Moby\Checkout\Model\Service\OrderStatusProcessor;
use Moby\Checkout\Model\Service\RequestDataExtractor;
use Moby\Checkout\Model\Service\SignatureValidator;

class Index extends Action implements CsrfAwareActionInterface, HttpGetActionInterface, HttpPostActionInterface
{
    private RequestDataExtractor $requestDataExtractor;

    private SignatureValidator $signatureValidator;

    private OrderFactory $orderFactory;

    private OrderStatusProcessor $orderStatusProcessor;

    private Logger $logger;

    private Config $config;

    private CheckoutSession $checkoutSession;

    private OrderRepositoryInterface $orderRepository;

    public function __construct(
        Context $context,
        RequestDataExtractor $requestDataExtractor,
        SignatureValidator $signatureValidator,
        OrderFactory $orderFactory,
        OrderStatusProcessor $orderStatusProcessor,
        Logger $logger,
        Config $config,
        CheckoutSession $checkoutSession,
        OrderRepositoryInterface $orderRepository
    ) {
        parent::__construct($context);
        $this->requestDataExtractor = $requestDataExtractor;
        $this->signatureValidator = $signatureValidator;
        $this->orderFactory = $orderFactory;
        $this->orderStatusProcessor = $orderStatusProcessor;
        $this->logger = $logger;
        $this->config = $config;
        $this->checkoutSession = $checkoutSession;
        $this->orderRepository = $orderRepository;
    }

    public function execute(): ResultRedirect
    {
        /** @var ResultRedirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $payload = $this->requestDataExtractor->extract($this->getRequest());

        $referenceNo = trim((string)($payload['referenceNo'] ?? ''));
        $incrementId = $this->resolveIncrementId($referenceNo);
        if ($incrementId === '') {
            $this->messageManager->addErrorMessage(__('Payment response is missing order reference.'));
            return $resultRedirect->setPath('checkout/onepage/failure');
        }

        $order = $this->orderFactory->create()->loadByIncrementId($incrementId);
        if (!$order->getEntityId()) {
            $this->messageManager->addErrorMessage(__('Order could not be found for payment response.'));
            return $resultRedirect->setPath('checkout/onepage/failure');
        }

        $apiKey = $this->config->getApiKey((int)$order->getStoreId());
        if (!$this->signatureValidator->isValid($payload, $apiKey)) {
            $order->addCommentToStatusHistory('Mobypay: Invalid signature on return payload.');
            $this->orderRepository->save($order);
            $this->logger->warning('Mobypay return signature validation failed', [
                'reference_no' => $referenceNo,
                'increment_id' => $incrementId,
                'payload' => $payload,
            ]);
            $this->messageManager->addErrorMessage(__('Payment signature validation failed.'));
            return $resultRedirect->setPath('checkout/onepage/failure');
        }

        try {
            $this->orderStatusProcessor->process($order, $payload, false);
            $this->logger->info('Mobypay return processed successfully', [
                'reference_no' => $referenceNo,
                'increment_id' => $incrementId,
                'status' => (string)($payload['status'] ?? ''),
                'transaction_id' => (string)($payload['transactionId'] ?? ''),
            ]);
        } catch (\Throwable $exception) {
            $this->logger->error('Mobypay return processing failed', [
                'reference_no' => $referenceNo,
                'increment_id' => $incrementId,
                'error' => $exception->getMessage(),
            ]);
            $this->messageManager->addErrorMessage(__('We could not finalize your payment response. Please contact support.'));
            return $resultRedirect->setPath('checkout/onepage/failure');
        }

        $status = strtolower((string)($payload['status'] ?? ''));
        if (in_array($status, ['success', 'processing'], true)) {
            $this->checkoutSession->setLastSuccessQuoteId((int)$order->getQuoteId());
            $this->checkoutSession->setLastQuoteId((int)$order->getQuoteId());
            $this->checkoutSession->setLastOrderId((int)$order->getEntityId());
            $this->checkoutSession->setLastRealOrderId((string)$order->getIncrementId());
            return $resultRedirect->setPath('checkout/onepage/success');
        }

        return $resultRedirect->setPath('checkout/onepage/failure');
    }

    public function createCsrfValidationException(RequestInterface $request): ?InvalidRequestException
    {
        return null;
    }

    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
    }

    private function resolveIncrementId(string $referenceNo): string
    {
        if ($referenceNo === '') {
            return '';
        }

        if (preg_match('/^MAGE-([0-9]+)-[0-9]+$/', $referenceNo, $matches) === 1) {
            return (string)$matches[1];
        }

        return $referenceNo;
    }
}
