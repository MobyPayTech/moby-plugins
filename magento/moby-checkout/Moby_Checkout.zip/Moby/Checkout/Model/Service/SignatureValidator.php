<?php
declare(strict_types=1);

namespace Moby\Checkout\Model\Service;

class SignatureValidator
{
    /**
     * @param array<string, mixed> $data
     */
    public function isValid(array $data, string $apiKey): bool
    {
        $signature = isset($data['signature']) ? (string)$data['signature'] : '';
        if ($signature === '' || $apiKey === '') {
            return false;
        }

        $payload = $data;
        foreach (['signature', 'key', 'mobypay_order_id', 'type', '?referenceNo'] as $key) {
            unset($payload[$key]);
        }

        foreach (['referenceNo', 'transactionId', 'amount', 'payMethod', 'status'] as $requiredKey) {
            if (!array_key_exists($requiredKey, $payload) || (string)$payload[$requiredKey] === '') {
                return false;
            }
        }

        ksort($payload);

        $concatenated = '';
        foreach ($payload as $value) {
            if (is_array($value)) {
                continue;
            }
            $concatenated .= (string)$value;
        }

        $calculated = hash_hmac('sha256', $concatenated, $apiKey);
        return hash_equals($calculated, $signature);
    }
}
