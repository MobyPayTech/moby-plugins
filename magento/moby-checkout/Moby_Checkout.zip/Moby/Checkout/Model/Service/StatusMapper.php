<?php
declare(strict_types=1);

namespace Moby\Checkout\Model\Service;

class StatusMapper
{
    /**
     * @return array<string, bool|string>
     */
    public function map(string $status): array
    {
        $normalized = strtolower(trim($status));

        return match ($normalized) {
            'success' => [
                'status' => 'success',
                'should_mark_paid' => true,
                'comment' => 'Mobypay: Payment successful.',
            ],
            'failed' => [
                'status' => 'failed',
                'should_mark_paid' => false,
                'comment' => 'Mobypay: Payment failed.',
            ],
            'cancelled' => [
                'status' => 'cancelled',
                'should_mark_paid' => false,
                'comment' => 'Mobypay: Payment cancelled by customer.',
            ],
            'processing' => [
                'status' => 'processing',
                'should_mark_paid' => false,
                'comment' => 'Mobypay: Payment is processing.',
            ],
            default => [
                'status' => $normalized !== '' ? $normalized : 'unknown',
                'should_mark_paid' => false,
                'comment' => 'Mobypay: Payment returned unknown status.',
            ],
        };
    }
}
