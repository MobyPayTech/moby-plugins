<?php
declare(strict_types=1);

namespace Moby\Checkout\Model\Service;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Framework\UrlInterface;
use Magento\Sales\Api\Data\OrderInterface;
use Moby\Checkout\Logger\Logger;
use Moby\Checkout\Model\Api\Client;
use Moby\Checkout\Model\Config;

class CheckoutService
{
    private Client $client;

    private TokenService $tokenService;

    private Config $config;

    private UrlInterface $urlBuilder;

    private Json $json;

    private Logger $logger;

    public function __construct(
        Client $client,
        TokenService $tokenService,
        Config $config,
        UrlInterface $urlBuilder,
        Json $json,
        ?Logger $logger = null
    ) {
        $this->client = $client;
        $this->tokenService = $tokenService;
        $this->config = $config;
        $this->urlBuilder = $urlBuilder;
        $this->json = $json;
        $this->logger = $logger ?? ObjectManager::getInstance()->get(Logger::class);
    }

    /**
     * @return array{payLink: string, payload: array<string, mixed>}
     * @throws LocalizedException
     */
    public function createHostedCheckout(OrderInterface $order): array
    {
        $storeId = (int)$order->getStoreId();
        $incrementId = (string)$order->getIncrementId();
        $referenceNo = $this->buildReferenceNo($order);

        $this->logger->info('Mobypay checkout: createHostedCheckout started.', [
            'reference_no' => $referenceNo,
            'increment_id' => $incrementId,
            'store_id' => $storeId,
            'base_url' => $this->config->getBaseUrl($storeId),
        ]);

        $token = $this->tokenService->getToken($storeId);
        $this->logger->info('Mobypay checkout: token generated.', [
            'reference_no' => $referenceNo,
            'token_length' => strlen($token),
        ]);

        $callbackUrl = $this->urlBuilder->getUrl('moby/checkout_callback/index', ['_secure' => true]);
        $returnUrl = $this->urlBuilder->getUrl('moby/checkout_return/index', ['_secure' => true]);

        $payload = [
            'clientId' => $this->config->getMerchantId($storeId),
            'customerName' => trim((string)$order->getCustomerFirstname() . ' ' . (string)$order->getCustomerLastname()),
            'customerEmail' => (string)$order->getCustomerEmail(),
            'customerMobile' => (string)($order->getBillingAddress()?->getTelephone() ?? ''),
            'referenceNo' => $referenceNo,
            'details' => 'Magento Order #' . $incrementId,
            'amount' => number_format((float)$order->getGrandTotal(), 2, '.', ''),
            'callbackUrl' => $callbackUrl,
            'returnUrl' => $returnUrl,
            'additionalInfo' => $this->buildAdditionalInfo($order),
        ];

        $this->logger->info('Mobypay checkout: prepared hosted-checkout payload.', [
            'reference_no' => $referenceNo,
            'increment_id' => $incrementId,
            'callback_url' => $callbackUrl,
            'return_url' => $returnUrl,
            'payload' => $this->maskPayloadForLog($payload),
        ]);

        $response = $this->client->post(
            $this->config->getBaseUrl($storeId),
            '/api/merchant/payment/checkout/hosted',
            $payload,
            ['Authorization' => 'Bearer ' . $token]
        );
        $this->logger->info('Mobypay checkout: hosted-checkout API response received.', [
            'reference_no' => $referenceNo,
            'increment_id' => $incrementId,
            'response' => $response,
        ]);

        $payLink = $response['payLink'] ?? '';
        if (!is_string($payLink) || $payLink === '') {
            $this->logger->error('Mobypay checkout: payLink missing in API response.', [
                'reference_no' => $referenceNo,
                'increment_id' => $incrementId,
                'response' => $response,
            ]);
            throw new LocalizedException(__('Payment gateway did not return a payment link.'));
        }

        $this->logger->info('Mobypay checkout: payLink generated successfully.', [
            'reference_no' => $referenceNo,
            'increment_id' => $incrementId,
            'pay_link' => $payLink,
        ]);

        return ['payLink' => $payLink, 'payload' => $payload];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private function maskPayloadForLog(array $payload): array
    {
        if (isset($payload['customerEmail'])) {
            $payload['customerEmail'] = $this->maskValue((string)$payload['customerEmail']);
        }
        if (isset($payload['customerMobile'])) {
            $payload['customerMobile'] = $this->maskValue((string)$payload['customerMobile']);
        }

        return $payload;
    }

    private function maskValue(string $value): string
    {
        $length = strlen($value);
        if ($length <= 4) {
            return str_repeat('*', $length);
        }

        return substr($value, 0, 2) . str_repeat('*', $length - 4) . substr($value, -2);
    }

    private function buildReferenceNo(OrderInterface $order): string
    {
        $incrementId = (string)$order->getIncrementId();
        $entityId = (int)$order->getEntityId();
        if ($entityId <= 0) {
            $entityId = time();
        }

        return sprintf('MAGE-%s-%d', $incrementId, $entityId);
    }

    /**
     * Scaffolded refund endpoint integration for future admin action wiring.
     *
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     * @throws LocalizedException
     */
    public function refund(OrderInterface $order, array $payload): array
    {
        $storeId = (int)$order->getStoreId();
        $token = $this->tokenService->getToken($storeId);

        return $this->client->post(
            $this->config->getBaseUrl($storeId),
            '/api/merchant/payment/refund',
            $payload,
            ['Authorization' => 'Bearer ' . $token]
        );
    }

    /**
     * @return array<string, mixed>
     */
    private function buildAdditionalInfo(OrderInterface $order): array
    {
        $items = [];
        foreach ($order->getAllVisibleItems() as $item) {
            $items[] = [
                'name' => (string)$item->getName(),
                'qty' => (float)$item->getQtyOrdered(),
                'price' => number_format((float)$item->getPrice(), 2, '.', ''),
                'rowTotal' => number_format((float)$item->getRowTotal(), 2, '.', ''),
            ];
        }

        return [
            'orderId' => (string)$order->getIncrementId(),
            'companyName' => $this->config->getCompanyName((int)$order->getStoreId()),
            'currency' => (string)$order->getOrderCurrencyCode(),
            'items' => $items,
            'totals' => [
                'subtotal' => number_format((float)$order->getSubtotal(), 2, '.', ''),
                'shipping' => number_format((float)$order->getShippingAmount(), 2, '.', ''),
                'tax' => number_format((float)$order->getTaxAmount(), 2, '.', ''),
                'grandTotal' => number_format((float)$order->getGrandTotal(), 2, '.', ''),
            ],
            'meta' => $this->json->serialize([
                'store' => (string)$order->getStoreName(),
                'customerId' => (string)$order->getCustomerId(),
            ]),
        ];
    }
}
