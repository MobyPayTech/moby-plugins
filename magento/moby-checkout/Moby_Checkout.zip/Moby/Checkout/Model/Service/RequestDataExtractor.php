<?php
declare(strict_types=1);

namespace Moby\Checkout\Model\Service;

use Magento\Framework\App\RequestInterface;
use Magento\Framework\Serialize\Serializer\Json;

class RequestDataExtractor
{
    private Json $json;

    public function __construct(Json $json)
    {
        $this->json = $json;
    }

    /**
     * @return array<string, mixed>
     */
    public function extract(RequestInterface $request): array
    {
        $query = $request->getQueryValue();
        $queryData = is_array($query) ? $query : [];

        $post = $request->getPostValue();
        $postData = is_array($post) ? $post : [];

        $jsonData = [];
        $rawBody = trim((string)$request->getContent());
        if ($rawBody !== '') {
            try {
                $decoded = $this->json->unserialize($rawBody);
                if (is_array($decoded)) {
                    $jsonData = $decoded;
                }
            } catch (\InvalidArgumentException $exception) {
                $jsonData = [];
            }
        }

        return array_replace($queryData, $postData, $jsonData);
    }
}
