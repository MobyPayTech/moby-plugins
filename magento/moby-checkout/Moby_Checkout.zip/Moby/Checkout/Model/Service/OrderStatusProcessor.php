<?php
declare(strict_types=1);

namespace Moby\Checkout\Model\Service;

use Magento\Framework\DB\TransactionFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Service\InvoiceService;
use Magento\Sales\Model\Order;
use Moby\Checkout\Logger\Logger;

class OrderStatusProcessor
{
    private OrderRepositoryInterface $orderRepository;

    private InvoiceService $invoiceService;

    private TransactionFactory $transactionFactory;

    private StatusMapper $statusMapper;

    private Logger $logger;

    public function __construct(
        OrderRepositoryInterface $orderRepository,
        InvoiceService $invoiceService,
        TransactionFactory $transactionFactory,
        StatusMapper $statusMapper,
        Logger $logger
    ) {
        $this->orderRepository = $orderRepository;
        $this->invoiceService = $invoiceService;
        $this->transactionFactory = $transactionFactory;
        $this->statusMapper = $statusMapper;
        $this->logger = $logger;
    }

    /**
     * @param array<string, mixed> $payload
     * @throws LocalizedException
     */
    public function process(Order $order, array $payload, bool $isCallback = false): void
    {
        $mapped = $this->statusMapper->map((string)($payload['status'] ?? ''));
        $payment = $order->getPayment();
        if ($payment === null) {
            throw new LocalizedException(__('Order payment object is missing.'));
        }

        $status = (string)$mapped['status'];
        $transactionId = (string)($payload['transactionId'] ?? '');

        $payment->setAdditionalInformation('moby_payload', $payload);
        $payment->setAdditionalInformation('moby_status', $status);
        $payment->setAdditionalInformation('moby_pay_method', (string)($payload['payMethod'] ?? ''));

        if ($transactionId !== '') {
            $payment->setAdditionalInformation('moby_transaction_id', $transactionId);
        }

        if ((bool)$mapped['should_mark_paid']) {
            if ($this->isAlreadyPaid($order, $transactionId)) {
                if ($isCallback) {
                    $order->addCommentToStatusHistory('Mobypay: Duplicate success callback ignored.');
                    $this->orderRepository->save($order);
                }
                return;
            }

            if ($transactionId !== '') {
                $payment->setTransactionId($transactionId);
                $payment->setLastTransId($transactionId);
            }

            if ($order->canInvoice()) {
                $invoice = $this->invoiceService->prepareInvoice($order);
                $invoice->register();
                $invoice->pay();
                $order->setIsInProcess(true);
                $transaction = $this->transactionFactory->create();
                $transaction->addObject($invoice)->addObject($order)->save();
            }

            $order->setState(Order::STATE_PROCESSING);
            $order->setStatus(Order::STATE_PROCESSING);
            $order->addCommentToStatusHistory((string)$mapped['comment']);
        } else {
            $order->addCommentToStatusHistory((string)$mapped['comment']);
        }

        $this->orderRepository->save($order);
    }

    private function isAlreadyPaid(Order $order, string $transactionId): bool
    {
        $payment = $order->getPayment();
        if ($payment === null) {
            return false;
        }

        if ((float)$order->getTotalPaid() > 0.0001) {
            return true;
        }

        if (in_array($order->getState(), [Order::STATE_PROCESSING, Order::STATE_COMPLETE], true)) {
            return true;
        }

        if ($transactionId !== '' && (string)$payment->getLastTransId() === $transactionId) {
            return true;
        }

        return false;
    }
}
