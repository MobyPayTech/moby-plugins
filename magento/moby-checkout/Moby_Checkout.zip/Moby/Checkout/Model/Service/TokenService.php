<?php
declare(strict_types=1);

namespace Moby\Checkout\Model\Service;

use Magento\Framework\App\ObjectManager;
use Magento\Framework\Exception\LocalizedException;
use Moby\Checkout\Logger\Logger;
use Moby\Checkout\Model\Api\Client;
use Moby\Checkout\Model\Config;

class TokenService
{
    private Client $client;

    private Config $config;

    private Logger $logger;

    public function __construct(Client $client, Config $config, ?Logger $logger = null)
    {
        $this->client = $client;
        $this->config = $config;
        $this->logger = $logger ?? ObjectManager::getInstance()->get(Logger::class);
    }

    /**
     * @throws LocalizedException
     */
    public function getToken(?int $storeId = null): string
    {
        $baseUrl = $this->config->getBaseUrl($storeId);
        $merchantId = $this->config->getMerchantId($storeId);
        $secretKey = $this->config->getApiKey($storeId);

        $this->logger->info('Mobypay token: request started.', [
            'store_id' => $storeId,
            'base_url' => $baseUrl,
            'endpoint' => '/api/auth/token',
            'merchant_id' => $merchantId,
            'secret_key_length' => $secretKey,
        ]);

        $response = $this->client->post(
            $baseUrl,
            '/api/auth/token',
            [
                'clientId' => $merchantId,
                'secretKey' => $secretKey,
            ]
        );
        $this->logger->info('Mobypay token: response received.', [
            'store_id' => $storeId,
            'response' => $response,
        ]);

        $token = $response['token'] ?? '';
        if (!is_string($token) || $token === '') {
            $this->logger->error('Mobypay token: invalid token response.', [
                'store_id' => $storeId,
                'response' => $response,
            ]);
            throw new LocalizedException(__('Payment gateway token response was invalid.'));
        }

        $this->logger->info('Mobypay token: token accepted.', [
            'store_id' => $storeId,
            'token_length' => strlen($token),
        ]);

        return $token;
    }
}
