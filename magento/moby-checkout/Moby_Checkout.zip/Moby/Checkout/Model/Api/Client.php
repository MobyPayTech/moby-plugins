<?php
declare(strict_types=1);

namespace Moby\Checkout\Model\Api;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\HTTP\Client\Curl;
use Magento\Framework\Serialize\Serializer\Json;
use Moby\Checkout\Logger\Logger;

class Client
{
    private Curl $curl;

    private Json $json;

    private Logger $logger;

    public function __construct(Curl $curl, Json $json, Logger $logger)
    {
        $this->curl = $curl;
        $this->json = $json;
        $this->logger = $logger;
    }

    /**
     * @param array<string, mixed> $payload
     * @param array<string, string> $headers
     * @return array<string, mixed>
     * @throws LocalizedException
     */
    public function post(string $baseUrl, string $endpoint, array $payload, array $headers = []): array
    {
        $url = rtrim($baseUrl, '/') . '/' . ltrim($endpoint, '/');

        $requestHeaders = ['Content-Type' => 'application/json', 'Accept' => 'application/json'];
        $requestHeaders = array_merge($requestHeaders, $headers);

        try {
            $this->curl->setTimeout(30);
            $this->curl->setHeaders($requestHeaders);
            $this->curl->post($url, $this->json->serialize($payload));
        } catch (\Throwable $exception) {
            $this->logger->error('Mobypay API request failed', [
                'url' => $url,
                'error' => $exception->getMessage(),
            ]);
            throw new LocalizedException(__('Unable to connect to payment gateway. Please try again.'));
        }

        $statusCode = (int)$this->curl->getStatus();
        $responseBody = (string)$this->curl->getBody();

        if ($statusCode < 200 || $statusCode >= 300) {
            $this->logger->error('Mobypay API returned non-success status', [
                'url' => $url,
                'status_code' => $statusCode,
                'response' => $responseBody,
            ]);
            throw new LocalizedException(__('Payment gateway rejected the request. Please try again.'));
        }

        if ($responseBody === '') {
            return [];
        }

        try {
            $decoded = $this->json->unserialize($responseBody);
            return is_array($decoded) ? $decoded : [];
        } catch (\InvalidArgumentException $exception) {
            $this->logger->error('Mobypay API returned invalid JSON', [
                'url' => $url,
                'response' => $responseBody,
            ]);
            throw new LocalizedException(__('Payment gateway returned an unexpected response.'));
        }
    }
}
