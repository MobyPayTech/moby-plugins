<?php
declare(strict_types=1);

namespace Moby\Checkout\Model\Config\Source;

use Magento\Framework\Data\OptionSourceInterface;

class Mode implements OptionSourceInterface
{
    /**
     * @return array<int, array<string, string>>
     */
    public function toOptionArray(): array
    {
        return [
            ['value' => 'test', 'label' => __('Sandbox')],
            ['value' => 'live', 'label' => __('Production')],
        ];
    }
}
