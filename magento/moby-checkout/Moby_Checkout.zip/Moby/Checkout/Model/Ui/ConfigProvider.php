<?php
declare(strict_types=1);

namespace Moby\Checkout\Model\Ui;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Framework\Escaper;
use Magento\Payment\Helper\Data as PaymentHelper;
use Moby\Checkout\Model\Config;

class ConfigProvider implements ConfigProviderInterface
{
    private PaymentHelper $paymentHelper;

    private Config $config;

    private Escaper $escaper;

    public function __construct(PaymentHelper $paymentHelper, Config $config, Escaper $escaper)
    {
        $this->paymentHelper = $paymentHelper;
        $this->config = $config;
        $this->escaper = $escaper;
    }

    /**
     * @return array<string, mixed>
     */
    public function getConfig(): array
    {
        $method = $this->paymentHelper->getMethodInstance(Config::METHOD_CODE);
        if (!$method->isAvailable()) {
            return [];
        }

        return [
            'payment' => [
                Config::METHOD_CODE => [
                    'description' => nl2br($this->escaper->escapeHtml($this->config->getDescription())),
                    'showVisaLogo' => $this->config->shouldShowVisaLogo(),
                    'showMastercardLogo' => $this->config->shouldShowMastercardLogo(),
                    'showMaybankLogo' => $this->config->shouldShowMaybankLogo(),
                    'showFpxLogo' => $this->config->shouldShowFpxLogo(),
                ],
            ],
        ];
    }
}
