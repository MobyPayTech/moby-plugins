<?php
declare(strict_types=1);

namespace Moby\Checkout\Model\Payment;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\UrlInterface;
use Magento\Payment\Model\Method\AbstractMethod;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Sales\Model\Order;
use Moby\Checkout\Model\Config;

class MobyCheckout extends AbstractMethod
{
    protected $_code = Config::METHOD_CODE;

    protected $_isInitializeNeeded = true;

    protected $_isGateway = true;

    protected $_canOrder = true;

    protected $_canAuthorize = false;

    protected $_canCapture = false;

    protected $_canRefund = false;

    protected $_canUseInternal = true;

    protected $_canUseCheckout = true;

    protected $_isOffline = false;

    private Config $config;

    private UrlInterface $urlBuilder;

    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory,
        \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory,
        \Magento\Payment\Helper\Data $paymentData,
        \Magento\Framework\App\Config\ScopeConfigInterface $appConfig,
        \Magento\Payment\Model\Method\Logger $logger,
        Config $config,
        UrlInterface $urlBuilder,
        ?\Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        ?\Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        parent::__construct(
            $context,
            $registry,
            $extensionFactory,
            $customAttributeFactory,
            $paymentData,
            $appConfig,
            $logger,
            $resource,
            $resourceCollection,
            $data
        );
        $this->config = $config;
        $this->urlBuilder = $urlBuilder;
    }

    public function initialize($paymentAction, $stateObject): void
    {
        $stateObject->setState(Order::STATE_PENDING_PAYMENT);
        $stateObject->setStatus(Order::STATE_PENDING_PAYMENT);
        $stateObject->setIsNotified(false);
    }  

    public function getOrderPlaceRedirectUrl(): string
    {
        return $this->urlBuilder->getUrl('moby/checkout_redirect/index');
    }

    public function isAvailable(?CartInterface $quote = null): bool
    {
        if (!parent::isAvailable($quote)) {
            $this->logAvailability('Parent availability check failed', $quote);
            return false;
        }

        $storeId = $quote ? (int)$quote->getStoreId() : null;
        if (!$this->config->hasRequiredCredentials($storeId)) {
            $this->logAvailability('Required credentials are missing', $quote, ['store_id' => $storeId]);
            return false;
        }

        $quoteCurrency = strtoupper((string)($quote?->getQuoteCurrencyCode() ?: $quote?->getBaseCurrencyCode()));
        if ($quoteCurrency !== '' && $quoteCurrency !== 'MYR') {
            $this->logAvailability('Currency is not MYR', $quote, ['quote_currency' => $quoteCurrency]);
            return false;
        }

        return true;
    }

    /**
     * @param array<string, mixed> $extra
     */
    private function logAvailability(string $reason, ?CartInterface $quote, array $extra = []): void
    {
        $debug = [
            'payment_method' => Config::METHOD_CODE,
            'reason' => $reason,
            'quote_id' => $quote ? (int)$quote->getId() : null,
            'quote_currency' => $quote ? (string)$quote->getQuoteCurrencyCode() : null,
            'base_currency' => $quote ? (string)$quote->getBaseCurrencyCode() : null,
            'store_id' => $quote ? (int)$quote->getStoreId() : null,
        ];

        if ($extra) {
            $debug = array_merge($debug, $extra);
        }

        $this->_logger->debug('Moby checkout availability check', $debug);
    }

    /**
     * @throws LocalizedException
     */
    public function validate(): self
    {
        parent::validate();

        $paymentInfo = $this->getInfoInstance();
        $order = $paymentInfo ? $paymentInfo->getOrder() : null;

        if ($order && strtoupper((string)$order->getOrderCurrencyCode()) !== 'MYR') {
            throw new LocalizedException(__('Moby Checkout is only available for MYR currency orders.'));
        }

        if (!$this->config->hasRequiredCredentials((int)$order?->getStoreId())) {
            throw new LocalizedException(__('Moby Checkout is not configured correctly. Please contact store administrator.'));
        }

        return $this;
    }

    public function assignData(\Magento\Framework\DataObject $data): self
    {
        parent::assignData($data);
        return $this;
    }

    public function canUseForCurrency($currencyCode): bool
    {
        return strtoupper((string)$currencyCode) === 'MYR';
    }

    public function isInitializeNeeded(): bool
    {
        return true;
    }

    public function canRefund(): bool
    {
        return false;
    }

    public function getConfigPaymentAction(): string
    {
        return self::ACTION_ORDER;
    }

    public function getInstructions(): string
    {
        return (string)$this->getConfigData('description');
    }
}
