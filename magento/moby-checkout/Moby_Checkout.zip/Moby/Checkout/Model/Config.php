<?php
declare(strict_types=1);

namespace Moby\Checkout\Model;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Encryption\EncryptorInterface;
use Magento\Store\Model\ScopeInterface;

class Config
{
    public const METHOD_CODE = 'moby_checkout';

    private const XML_PATH_ACTIVE = 'payment/moby_checkout/active';
    private const XML_PATH_TITLE = 'payment/moby_checkout/title';
    private const XML_PATH_DESCRIPTION = 'payment/moby_checkout/description';
    private const XML_PATH_MODE = 'payment/moby_checkout/mode';
    private const XML_PATH_MERCHANT_ID = 'payment/moby_checkout/merchant_id';
    private const XML_PATH_API_KEY = 'payment/moby_checkout/api_key';
    private const XML_PATH_COMPANY_NAME = 'payment/moby_checkout/company_name';
    private const XML_PATH_SHOW_VISA = 'payment/moby_checkout/show_visa_logo';
    private const XML_PATH_SHOW_MASTERCARD = 'payment/moby_checkout/show_mastercard_logo';
    private const XML_PATH_SHOW_MAYBANK = 'payment/moby_checkout/show_maybank_logo';
    private const XML_PATH_SHOW_FPX = 'payment/moby_checkout/show_fpx_logo';

    private ScopeConfigInterface $scopeConfig;

    private EncryptorInterface $encryptor;

    public function __construct(
        ScopeConfigInterface $scopeConfig,
        ?EncryptorInterface $encryptor = null
    )
    {
        $this->scopeConfig = $scopeConfig;
        $this->encryptor = $encryptor ?? ObjectManager::getInstance()->get(EncryptorInterface::class);
    }

    public function isActive(?int $storeId = null): bool
    {
        return $this->scopeConfig->isSetFlag(self::XML_PATH_ACTIVE, ScopeInterface::SCOPE_STORE, $storeId);
    }

    public function getTitle(?int $storeId = null): string
    {
        return (string)$this->scopeConfig->getValue(self::XML_PATH_TITLE, ScopeInterface::SCOPE_STORE, $storeId);
    }

    public function getDescription(?int $storeId = null): string
    {
        return (string)$this->scopeConfig->getValue(self::XML_PATH_DESCRIPTION, ScopeInterface::SCOPE_STORE, $storeId);
    }

    public function getMode(?int $storeId = null): string
    {
        return (string)$this->scopeConfig->getValue(self::XML_PATH_MODE, ScopeInterface::SCOPE_STORE, $storeId);
    }

    public function isSandbox(?int $storeId = null): bool
    {
        return $this->getMode($storeId) !== 'live';
    }

    public function getMerchantId(?int $storeId = null): string
    {
        return trim((string)$this->scopeConfig->getValue(self::XML_PATH_MERCHANT_ID, ScopeInterface::SCOPE_STORE, $storeId));
    }

    public function getApiKey(?int $storeId = null): string
    {
        $value = trim((string)$this->scopeConfig->getValue(self::XML_PATH_API_KEY, ScopeInterface::SCOPE_STORE, $storeId));
        if ($value === '') {
            return '';
        }

        try {
            $decrypted = trim((string)$this->encryptor->decrypt($value));
            return $decrypted !== '' ? $decrypted : $value;
        } catch (\Throwable $exception) {
            return $value;
        }
    }

    public function getCompanyName(?int $storeId = null): string
    {
        return trim((string)$this->scopeConfig->getValue(self::XML_PATH_COMPANY_NAME, ScopeInterface::SCOPE_STORE, $storeId));
    }

    public function shouldShowVisaLogo(?int $storeId = null): bool
    {
        return $this->scopeConfig->isSetFlag(self::XML_PATH_SHOW_VISA, ScopeInterface::SCOPE_STORE, $storeId);
    }

    public function shouldShowMastercardLogo(?int $storeId = null): bool
    {
        return $this->scopeConfig->isSetFlag(self::XML_PATH_SHOW_MASTERCARD, ScopeInterface::SCOPE_STORE, $storeId);
    }

    public function shouldShowMaybankLogo(?int $storeId = null): bool
    {
        return $this->scopeConfig->isSetFlag(self::XML_PATH_SHOW_MAYBANK, ScopeInterface::SCOPE_STORE, $storeId);
    }

    public function shouldShowFpxLogo(?int $storeId = null): bool
    {
        return $this->scopeConfig->isSetFlag(self::XML_PATH_SHOW_FPX, ScopeInterface::SCOPE_STORE, $storeId);
    }

    public function getBaseUrl(?int $storeId = null): string
    {
        if ($this->isSandbox($storeId)) {
            return 'https://dev.pay.mobycheckout.com';
        }

        return 'https://pay.mobycheckout.com';
    }

    public function hasRequiredCredentials(?int $storeId = null): bool
    {
        return $this->getMerchantId($storeId) !== '' && $this->getApiKey($storeId) !== '';
    }
}
